import sys, subprocess, pathlib, xml.etree.ElementTree as ET
ADB=r"C:\Users\jisal\AppData\Local\Android\Sdk\platform-tools\adb.exe"
SERIAL="TG8HCYTGGQT885OF"
root=pathlib.Path(__file__).resolve().parent/"redmi-retest"
root.mkdir(exist_ok=True)
name=sys.argv[1]
assert name.replace("-", "").replace("_", "").isalnum()
image=root/(name+".png")
xml=root/(name+".xml")
assert not image.exists() and not xml.exists(), "Preserve prior capture"
def adb(*args):
 result=subprocess.run([ADB,"-s",SERIAL,*args],capture_output=True,timeout=45)
 with (root/(name+"-commands.log")).open("ab") as log:
  output = b"[PNG bytes retained separately]" if args[0] == "exec-out" else result.stdout
  log.write(repr(args).encode()+b"\n"+output+b"\n"+result.stderr+b"\n")
 result.check_returncode()
 return result.stdout
remote="/sdcard/cursor-buy-r6635-"+name+".xml"
receipt=adb("shell","uiautomator","dump",remote)
print(receipt.decode(errors="replace").encode("ascii",errors="replace").decode())
image.write_bytes(adb("exec-out","screencap","-p"))
assert b"dumped to:" in receipt, "Accessibility dump incomplete; screenshot and stderr preserved"
adb("pull",remote,str(xml))
print(str(image))
for node in ET.fromstring(xml.read_bytes()).iter("node"):
 label=node.get("text") or node.get("content-desc")
 if label:
  print(ascii(label),node.get("bounds"),"click="+str(node.get("clickable")))
