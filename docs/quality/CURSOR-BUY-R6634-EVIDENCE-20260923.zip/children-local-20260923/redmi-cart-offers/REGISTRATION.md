# Cart to Offers navigation finding

Status: open, reproduction pending. Registration only; no implementation.

Initial current-screen capture shows the MoolSocial main-actions launcher. Founder reports Cart then Offers caused it. Two explicit semantic-target replays returned Offers correctly, so the cause is unconfirmed.

1. Shop → scoped Cart → Offers: correct Offers destination.
2. Offers → all-baskets Cart → Offers: correct Offers destination.

Existing baskets remain intact (Shop 2 items INR680; combined 4 items INR2120). Final screen Offers. No purchases, messages, account changes, installs or code changes.

See registration.json for exact steps, evidence SHA-256 values, acceptance and synchronous-capture limitation for 02-shop.png/XML. Main agent assigns the durable ticket ID and records the finding in the existing handoff.
