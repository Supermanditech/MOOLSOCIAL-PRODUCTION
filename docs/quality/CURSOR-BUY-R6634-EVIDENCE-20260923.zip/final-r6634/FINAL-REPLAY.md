# r66.34 final Redmi replay

Build source 821590ce845f6719439fc92077ce3bf1eea23053. Installed SHA-256 6B624757007AF342491BE1360DC0EE0D625C5E265C889DF3C0A43BD6F5FD21AC.
Two full local Buy runs: 2535 passed / 27 skipped each. All 3246 sealed source inputs unchanged after build/device replay.

Review fixtures only. No live payment, sent chat, provider-issued PO, real delivery or production acceptance. One local COD order BUY-NEW-06/MS-NEW-11 was created. Original Wholesale basket remains 2 packs/INR1550; temporary Shop basket item removed. Invoice save dialog cancelled.

All 37 original records have a disposition; this is not a claim that all defects are closed. Five child records registered, including one explicit acceptance-coverage gap. Stop now without another implementation/build cycle.

{'closed_verified': 13, 'partial_child_registered': 12, 'open_dependency': 6, 'partial_dependency': 4, 'closed_superseded': 2}

| Record | Status | Disposition |
|---|---|---|
| R6633-D01 | closed_verified | Mixed MS-NEW-03 preparing estimate now says Delivery; delivered history remains Delivered. Evidence: redmi/r34-order-wording-search.png |
| R6633-D02 | partial_child_registered | Original Recent nested product Cart fixed. Retail Visit Store with only Wholesale basket still lacks aggregate Cart; C01. Evidence: redmi/r34-recent-product-final.png, redmi/r34-nested-product-scroll.png, redmi/r34-store-ready.png |
| R6633-D03 | closed_verified | Compact header and inline Add; host large-text variants qualified separately. Evidence: redmi/r34-recent.png, redmi/r34-recent-final.png |
| R6633-D04 | closed_verified | Transparent floating Cart on inspected Store and nested product surfaces; no white backing strip. Evidence: redmi/r34-store-added.png, redmi/r34-wholesale-store-ready.png, redmi/r34-nested-product-scroll.png |
| R6633-D05 | open_dependency | Authoritative comparable supplier/variant offers unavailable; refresh remains truthful. Evidence: redmi/r34-compare.png |
| R6633-D06 | partial_child_registered | Compact filter, inline Saved, inline price/Add and quiet browse verified; administrator data and C03/C05 remain. Evidence: redmi/r34-offers-filter-ready.png, redmi/r34-offers-saved.png, redmi/r34-offer-wholesale-product.png, redmi/r34-cart-scope.png |
| R6633-D07 | partial_dependency | Duplicate sign-in removed. Account binding unavailable; collection does not bypass verification. Evidence: redmi/r34-collection.png |
| R6633-D08 | partial_dependency | Platform delivery names render; authoritative service assignment remains deferred. Evidence: redmi/r34-shop-product.png, redmi/r34-offer-wholesale-product.png |
| R6633-D09 | partial_dependency | Store identity grouping qualified locally; authoritative shipment identity not supplied. Evidence: redmi/r34-wholesale-review.png |
| R6633-D10 | open_dependency | Live delivery explicitly unavailable; no live provider route or physical delivery claimed. Evidence: redmi/r34-tracking.png |
| R6633-D11 | open_dependency | PhonePe/Paytm review flow works but real provider handoff unavailable; no live payment. Evidence: redmi/r34-payment-unavailable.png, redmi/r34-wholesale-provider-unavailable.png |
| R6633-D12 | closed_verified | Unavailable attempt locks methods; cancellation restores selection and next review. Evidence: redmi/r34-payment-unavailable.png, redmi/r34-payment-cancelled.png, redmi/r34-review-cod.png |
| R6633-D13 | closed_verified | Timing preserves Dispatch within one day, not a fabricated arrival promise. Evidence: redmi/r34-wholesale-review.png |
| R6633-D14 | partial_child_registered | New Add reveals purchased item. Exhaustive Edit basket/scroll matrix remains C05. Evidence: redmi/r34-crossscope-add-cart.png |
| R6633-D15 | closed_superseded | PO reference and PO-as-payment removed; legitimate PO workflow remains D17. Evidence: redmi/r34-wholesale-payment.png, redmi/r34-payment.png |
| R6633-D16 | partial_child_registered | New Buy/invoice names normalized; historical Orders and chat retain padded names, C02. Evidence: redmi/r34-supplier-chat.png, redmi/r34-orders.png, redmi/r34-invoice.png |
| R6633-D17 | partial_dependency | PO removed from payment and supplier chat works. Issuance, buyer approval, supplier acceptance, communication lifecycle still incomplete, not solely backend acceptance. Evidence: redmi/r34-wholesale-payment.png, redmi/r34-supplier-chat.png |
| R6633-D06-D-C1 | closed_verified | Saved Wholesale offer is accessible from Offers even after Shop context; inline presentation. Evidence: redmi/r34-offers-saved.png, redmi/r34-offer-wholesale-product.png |
| R6633-D06-G-C1 | closed_superseded | No stale PO reference field remains; D17 owns replacement workflow. Evidence: redmi/r34-payment.png, redmi/r34-wholesale-payment.png |
| R6633-D08-C1 | open_dependency | Schedule independent of transport requires authoritative Store/logistics assignment. Evidence: redmi/r34-wholesale-review.png |
| R6633-D09-C1 | open_dependency | Authoritative stable fulfilment IDs remain integration dependency. Evidence: redmi/r34-wholesale-review.png |
| R6633-D12-C1 | closed_verified | Cancelled Wholesale payment then Shop Add succeeds, original basket preserved. Evidence: redmi/r34-wholesale-provider-unavailable.png, redmi/r34-crossscope-add-cart.png |
| R6633-D06-G-V01 | closed_verified | Inline price/Add on Shop and Wholesale offer details; Cart item visible on entry. Evidence: redmi/r34-shop-product.png, redmi/r34-offer-wholesale-product.png, redmi/r34-cart-scope.png |
| R6633-D06-G-V02 | closed_verified | Quiet browse, aligned price/quantity and persistent total/Checkout on inspected scopes. Evidence: redmi/r34-cart-scope.png, redmi/r34-wholesale-cart.png |
| R6633-D06-G-V03 | partial_child_registered | Address/pickup frontends inspected. Compact lower-field/validation matrix remains C05; account binding deferred. Evidence: redmi/r34-address-edit.png, redmi/r34-address-keyboard.png, redmi/r34-collection.png |
| R6633-D06-G-V04 | closed_verified | Compact methods, no PO field, explicit recovery; production provider success excluded. Evidence: redmi/r34-payment.png, redmi/r34-payment-cancelled.png, redmi/r34-wholesale-payment.png |
| R6633-D06-G-V05 | partial_child_registered | Review works, but Wholesale duplicates product/amount across shipment and trade table, C03. Evidence: redmi/r34-review-phonepe.png, redmi/r34-wholesale-review.png |
| R6633-D06-G-V06 | closed_verified | Compact confirmation and next action verified with labelled local COD order only. Evidence: redmi/r34-local-cod-confirmation.png |
| R6633-D06-G-V07 | partial_child_registered | Compact actions work; empty historical Payment section C04 and provider completion remain. Evidence: redmi/r34-tracking-actions.png, redmi/r34-invoice.png, redmi/r34-delivered-detail.png |
| R6633-D06-G-V08 | partial_child_registered | Normal-size device samples inspected and local enlarged-text renders passed; complete physical-device variant matrix C05. Evidence: redmi/r34-shop-product.png, redmi/r34-cart-scope.png, redmi/r34-wholesale-review.png |
| R6633-D06-G-V09 | partial_child_registered | Inspected keyboard/form cases retain content; exhaustive lower-field/correction matrix C05, not a blanket keyboard pass. Evidence: redmi/r34-address-keyboard.png, redmi/r34-chat-keyboard.png, redmi/r34-wholesale-quantity.png |
| R6633-D06-G-V07-C1 | partial_child_registered | Payment facts reduced; historical status repetition and empty Payment remain C04. Evidence: redmi/r34-orders.png, redmi/r34-tracking.png, redmi/r34-delivered-detail.png |
| R6633-D06-G-V07-C2 | closed_verified | Compact single cancellation choice and correctly named quiet supplier action. Evidence: redmi/r34-manage-order.png |
| R6633-D06-G-V07-C3 | partial_child_registered | Historical delivered fixture visible; returns correctly unavailable. Collected/partial receipt qualified locally only, full device matrix C05. Evidence: redmi/r34-delivered-detail.png, redmi/r34-delivered-return.png, redmi/r34-return-reason.png |
| R6633-D17-C1 | closed_verified | Contact supplier opens supplier order conversation. No message sent. Evidence: redmi/r34-manage-order.png, redmi/r34-supplier-chat.png |
| R6633-D17-C2 | partial_child_registered | Concise draft and compact context; padded name/truncated party subtitle remain C02. Evidence: redmi/r34-supplier-chat.png, redmi/r34-chat-keyboard.png |
| R6633-D10-C2 | open_dependency | Google live map and provider location/events remain mandatory before go-live. Evidence: redmi/r34-tracking.png |

## Open children

### R6634-C01 — Retail Visit Store hides aggregate Cart when only Wholesale basket exists
Parents: R6633-D02. Retain a reachable aggregate Cart on every nested Store surface, even with no local-scope items. Do not add empty carts.
Evidence: redmi/r34-store-ready.png

### R6634-C02 — Public Store naming and chat header remain inconsistent
Parents: R6633-D16, R6633-D17-C2. Use the same safe public display identity in historical Orders and order chat, retaining full party/order access and legal identity. Header subtitle currently ellipsizes.
Evidence: redmi/r34-supplier-chat.png, redmi/r34-orders.png

### R6634-C03 — Wholesale review repeats product and subtotal
Parents: R6633-D06, R6633-D06-G-V05. Combine shipment items with pack/MOQ/unit-price facts in one compact table; preserve totals, tax, returns and Store grouping.
Evidence: redmi/r34-wholesale-review.png

### R6634-C04 — Historical tracking has empty Payment section and repeated status
Parents: R6633-D06-G-V07, R6633-D06-G-V07-C1. Hide empty payment group or provide truthful concise unavailable information; avoid repeated current status in history while preserving timeline facts.
Evidence: redmi/r34-delivered-detail.png, redmi/r34-orders.png

### R6634-C05 — Remaining acceptance matrix is not device-qualified
Parents: R6633-D06, R6633-D14, R6633-D06-G-V03, R6633-D06-G-V08, R6633-D06-G-V09, R6633-D06-G-V07-C3. Coverage gap, not a reproduced failure: complete Bulk-specific paths, every editable lower field/validation/back case, Edit basket scroll matrix, publisher rapid-switch frames, physical-device enlarged text and collected/partial receipt states using labelled fixtures. Existing local passes do not imply this entire Redmi matrix passed.
Evidence: redmi/r34-address-keyboard.png, redmi/r34-return-reason.png

