# R6633-D04 — Empty white strip behind fixed Cart

Status: OPEN — REGISTER ONLY, DO NOT IMPLEMENT. Founder reports this as a longstanding unresolved requirement.
Actor/outcome: public Buy customer browses products with Cart accessible without a redundant full-width blank band obscuring/reducing product space. Launch-supporting (mvp_supporting).

Device: Redmi TG8HCYTGGQT885OF. Installed r66.33-cursorreview, code 2026092202; verified APK SHA-256 968933D16519BBE6AC757C10ACA39368F87A7605CFAB0CF1F6C4E28DD73E1FC7. Start branch b03c339f8acbf50358cca5d4765068ee51936e60. No app or test code changes, APK rebuild, data clear or cart edits.

## Reproduction and actual result

The founder-current screen is public Shop > Premium basmati rice > Visit store > expanded empty Store search (keyboard hidden). Capture 051 records five Shop items / INR694. An opaque white band spans the entire screen around y1404–1506, while the small Cart pill occupies only the right edge. This is above the Android system navigation area. Product cards stop at the band. The same band remains after Finish search and on a product opened inside Store (052/053/054/064).

## Cross-surface inspection

| Surface | Evidence | Result |
|---|---|---|
| Founder-current Shop Store search | 051-founder-cart-strip | Confirmed full-width white Cart band; original screen captured before navigation. |
| Shop Visit Store catalogue | 052-shop-store-cart-strip, 054-return-store-strip, 064-restored-store | Confirmed. |
| Product opened inside Store | 053-store-product-cart-strip | Confirmed same redundant band below product content. |
| Wholesale Visit Store with Wholesale basket | Earlier 032-wholesale-store from the exact same r66.33 APK | Confirmed in retained screenshot: six Wholesale packs and same right-side pill/full-width white band. This is prior same-build evidence, not a new capture. |
| Wholesale Visit Store in current user state | 059-wholesale-store-no-scoped-cart | No Wholesale basket exists now, so scoped Cart and its band are absent. Five Shop items preserved; no item was added to fabricate coverage. |
| Shop root catalogue and root SKU | 056-shop-home-cart, 055-shop-root-cart | Cart inside normal navigation rail; no separate empty Store-style Cart strip reproduced. Keep rail background and Android safe area distinct from this defect. |
| Wholesale root catalogue | 057-wholesale-home-cart | Normal navigation Cart; separate blank band not reproduced. |
| Wholesale root SKU | 058-wholesale-product-cart | Normal navigation Cart. Additional full-width purchase footer contains MOQ/price/delivery/Add; not falsely classified as the empty Store Cart strip. Review its footprint under existing compact SKU ticket. |
| Orders and Offers | 060-orders-cart-strip, 061-offers-cart-strip | Normal navigation Cart; separate blank band not reproduced. |
| Saved Shop products | 062-saved-cart-strip | Normal navigation Cart; separate blank band not reproduced. |

All three `BuyV2StoreCartBar` call sites were inspected read-only: catalogue Store sheet (~6828), full catalogue (~8553), nested product route in buy_v2_screen (~2532). The shared widget (~7368) right-aligns a compact button in a full-width layout; parent Column reserves footer height below Expanded content. This explains the affected layout family; exact styling fix remains unimplemented. Full catalogue and nested Saved/Recent/related/comparison entry variants share these owners and belong to the follow-up matrix; not every entry was separately device-replayed. Root `_BuyMiniCartBar` navigation variant is a separate placement. No backend/Google dependency is needed to correct this visual defect.

## Required future acceptance

- Eliminate the redundant full-width opaque Cart-only band on every affected public Store/nested route. Maintain the page background/gradient and useful SKU space.
- Keep Cart fixed, reachable and compact; do not reintroduce automatic drifting, scroll disappearance or hidden controls. Preserve counts, destination scope, prices and Cart navigation.
- Preserve Android system safe insets and normal bottom navigation. Product content must remain scrollable into view and not become trapped beneath the Cart.
- Check Shop/Wholesale/Bulk/Offers/Orders/Saved, Visit Store, full catalogue, nested product, Recent/related/comparison entry routes wherever Cart is present; separate observed cases from shared-code inference.
- Include empty/one/multiple-destination baskets, long totals, scrolling, keyboard open/closed and category/filter sheets, enlarged text and landscape. Founder screenshots plus next Redmi replay required before closure.

Scope is registration only. Reuse buy_v2_catalogue.dart and buy_v2_screen.dart plus their existing focused tests when later authorized. No new screen/provider, Store business-rule changes, policy work, backend changes or implementation now. Parent: Cart position across all surfaces / founder longstanding white-strip report. Historical exact white-strip ticket ID was not established; this is a linked open child, not a claim that the old issue was resolved.

Preservation: five Shop items, INR694, one Saved item unchanged throughout inspection. No Add/Remove/coupon/address/order/payment action. Device returned to Shop Visit Store catalogue (search closed).
