# R6633-D05 — Compare prices cannot load offers; Refresh repeats unavailable

Status: OPEN FUNCTIONAL GAP / PROVIDER WIRING DEPENDENCY. Registration and inspection only; no implementation authorized by this report.
Founder: “why compare prics not fixed in previous ticket now its open on redme its not working”. Captured on 23 September 2026, Redmi TG8HCYTGGQT885OF, installed r66.33-cursorreview. Branch checkpoint 805df77565cb0bf5e27f229e015b87587f9c0a8b. Related parent CURSOR-BUY-COMPARE-SHEET-REGRESSION-20260922.

## Device reproduction

Founder-current product: Wholesale A4 ruled notebooks, Carton of 120. Compare prices says “Prices from other suppliers are unavailable right now. Try again.” Capture065 preserves original screen. Tap visible Refresh comparison once: capture066 shows same product/pack and unchanged unavailable message. No offers load. Device left on this sheet; no Cart/order/payment data changed.

## Why the earlier ticket did not complete this feature

The earlier recorded ticket scoped the repair to content-sized short/error/loading sheets, populated scrolling and navigation. Its acceptance item4 explicitly retained supplier-data unavailability as a separate dependency. The layout change is included in the installed APK; no omitted commit was found. Local populated-flow checks do not establish an app-wired supplier source.

Read-only source evidence: `_reload()` in apps/mobile/lib/ui_v2/buy/buy_v2_views.dart (~1964) reads `session.comparisonSource`. If source or exact query is null it disposes the controller, sets the unavailable message and returns BEFORE calling `load`. BuyV2Session's comparisonSource is nullable and optional (~1984/~3659). apps/mobile/lib/features/buy/buy_v2_content_contracts.dart defines BuyV2ComparisonSource.identityFor/load (~2491). Searching all apps/mobile/lib finds the interface/session/controller references but NO implementation of BuyV2ComparisonSource and NO `comparisonSource:` injection. Therefore the installed frontend has no connected supplier-comparison provider; Refresh cannot repair that missing wiring. This is not evidence of an internet outage. Other invalid-identity causes must also remain separately handled when a source is later connected.

The earlier broad “implemented” wording must not imply working price comparison end to end. Sheet layout implemented; functional provider integration OPEN. The earlier device-replay row15 was explicitly unavailable-state/provider-deferred, not populated comparison acceptance. Founder now calls out that the user outcome remains unmet.

## Bounded future ticket

Actor/outcome: Buy/Wholesale customer compares genuine same-product/variant/pack offers from published Store records, with correct prices/quantities/eligibility and functional retry. Classification mvp_supporting; depends on shared Store/public provider mapping, currently deferred.
Reuse existing comparison source/controller/sheet, session and public identity contract. No new comparison screen, invented Buy fixtures or fabricated live supplier prices. Exact runtime candidates: buy_v2_views.dart, buy_v2_session.dart, buy_v2_content_contracts.dart plus the subsequently coordinated Store-origin adapter/injection owner. No other worktree changes. Provider owner and revision must be established before implementation; this registration does not authorize backend work.

Acceptance: connect verified Store-origin identities and offers; distinguish provider-not-configured from transient network failure, invalid/missing exact identity, empty results and unavailable eligible offers. Do not offer a misleading endless retry as if configuration were a transient failure. Verify loading/empty/error/retry/success/pagination, same SKU+variant+pack, multiple eligible sellers, price/stock/freshness, location changes and stale-result rejection; exact Compare product/Store/Cart return. Test Shop/Wholesale/Visit Store/Saved/Recent/Offers entry routes. Content-sized safe Android/keyboard layout must remain. Device populated results require the exact provider handoff; simulated test responses must stay explicitly labelled and must not close live acceptance.

No application/test/configuration/policy changes, no build or installation, no backend/API activity. Preserve provider deferral and record this as incomplete, not fixed.
