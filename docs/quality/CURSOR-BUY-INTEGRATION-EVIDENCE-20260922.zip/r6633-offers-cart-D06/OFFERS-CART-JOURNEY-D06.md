# R6633-D06 — Offers consistency and compact Cart journey

Status: OPEN — INSPECTED AND REGISTERED ONLY. Seven work packages A–G; none implemented by this registration. Founder explicitly requested detailed inspection and visual/technical outcomes before implementation. Actual local Flutter screens are a future approval milestone, not a mockup or deliverable claimed complete now.

Recorded 23 September 2026. Actor: public Buy customer browsing Offers and reviewing a Shop/Wholesale basket. Classification: mvp_supporting, improving the existing commerce journey; no additional wholesale operations or admin workspace. Registration checkpoint: e3073148cb63023d6d2c47abae1e2c42f2bc0d0f. Redmi TG8HCYTGGQT885OF, com.moolsocial.app.cursorreview, r66.33-cursorreview, version code 2026092202. Installed APK SHA-256: 968933D16519BBE6AC757C10ACA39368F87A7605CFAB0CF1F6C4E28DD73E1FC7. This is a review build, not production acceptance.

## Inspection and preservation

Fresh captures067–081 and timed sequences070/071 are attached. Capture067 actually shows Cart when inspection began, despite its filename; it is not Offers evidence. Navigated Offers publisher controls, filter, Saved and Wholesale SKU; then Cart, address choices, payment choices and address editor/recipient keyboard. Returned to Cart in081. Basket remained four products/six Shop items/₹760; no Add, removal, Saved toggle, payment selection, address save, order placement or message sending. Existing saved addresses are review state, not newly entered data.

This inspection does not establish completion of every checkout branch. Final order submission, live payment/provider responses, all keyboard fields and real fulfilment remain untested here. Earlier same-APK captures005/055/062 support Shop price-row Add and inline Saved parity; earlier025 is only prior final-review evidence, not a new successful checkout.

## A — Stable Suppliers/MoolSocial switching

Observed: returning to Suppliers makes the selected label invisible and results blank in the first two sampled frames of071 (approximately first 1.5 seconds). The final sampled frame is readable with results by about5.7 seconds. Sparse captures do not establish the exact transition duration. MoolSocial sequence070 stays in the no-matching-offers state.

Expected visual result: both publisher labels remain legible throughout transitions, with the current brand selected/unselected treatment. Keep controls stable; use a compact result-region loading indicator rather than an unexplained blank page. Do not flash results from the previous publisher under the new heading.

Technical: reuse _OffersCategoryControl and _PagedPublishedOffersViewState in apps/mobile/lib/ui_v2/buy/buy_v2_catalogue.dart. Inspect foreground/background animation together; source style transitions are a suspected cause, not yet a proved root cause. Maintain query/publisher/category coherence, pagination, retry and location freshness. Rapid alternating taps must accept only the latest query result; keep Saved state intact. Test slow/error/empty/nonempty responses and repeated toggles with frame-level label-contrast evidence.

## B — Authoritative MoolSocial offer data dependency

Observed: no matching MoolSocial offers. The review BuyV2DevelopmentCatalogueSource._publisherType in apps/mobile/lib/features/buy/buy_v2_session.dart generates retailer/manufacturer/wholesaler publishers, never moolSocial. The exact-publisher filter therefore has no matching review records. This is not proof of an internet failure or of an empty production admin database.

Expected: published eligible offers from MoolSocial admin or the authoritative Supermandi Tech Pvt Ltd Store records, using the same Store/public data mapping. Reuse BuyV2PublishedCatalogueOffer and BuyV2PublishedCatalogueSource.loadOffers in buy_v2_content_contracts.dart. Existing fields: publicationId, product, publisherType, publisherId, publisherName, headline, sourceId, observedAt, validUntil. Preserve product/Store/SKU/variant/pack identity, photos, channel price, stock and eligibility. Company name alone must not silently grant the moolSocial publisher type; use the explicit authoritative publisher mapping.

Future fixture handoff must identify source revision and record IDs, include valid/expired/withdrawn/incomplete/unavailable cases, and label simulated transport responses. Terms missing from the existing contract require a coordinated field handoff, not invented discounts. Preserve honest empty/unavailable states. The founder wants reusable production test data later: records must then use designated test identity/environment and remain distinguishable from normal public offers. No record injection, production fixture exposure, backend/admin implementation or live-publication claim is authorized now. This package remains a Store/admin/provider dependency until that handoff exists.

## C — Compact Offers publisher filter

Observed072: five full-width publisher rows and a large header/handle region make the popup unnecessarily tall. Current _chooseOfferPublisher uses a scroll-controlled bottom sheet and five ListTiles.

Expected: content-sized compact sheet, short heading and close action, wrapping choice chips or a compact list with a clear selected mark. No fixed blank region, oversized header or unnecessary full-screen height. Preserve All publishers, Manufacturers, Wholesalers, Stores and MoolSocial, with understandable relation to the top publisher selector. Reuse current filter state and query; do not add a second filter system. Maintain accessible touch targets (approximately48 logical pixels), readable text, safe Android bottom inset, long-label wrapping and scrollability at enlarged text. Compact means less unused space, not tiny controls.

## D — Offers Saved parity and correct scope

Observed069/073: Offers has a saved Wholesale tomato product, but Saved opens a separate spacious popup labelled Shop · 1 saved, showing rice only. Source uses savedCountFor(session.destination), active:false and showBuyV2SavedProducts, so it inherits the last Shop/Wholesale destination rather than the displayed Offers cohort.

Child R6633-D06-D-C1: wrong Saved scope/count/content, not only styling.

Expected: reuse Buy/Shop's inline Saved toggle and existing product grid/card design. Offers Saved displays saved products represented by the applicable Offers cohort across Shop/Wholesale, respecting publisher/category/location filters. Count, selected state and displayed results must agree; remember stable product/Store/variant identity. Toggling back restores the preceding query/scroll behavior. Unsaving, no saved products, saved-but-unavailable/expired offers and filter-hidden products need truthful states; filtering must not delete saved records. No independent Offers bookmark store or duplicate popup. Shop and Wholesale Saved continue to work unchanged.

## E — Shared product price/Add placement

Observed074: Wholesale Fresh tomatoes 10kg from Offers shows price/MOQ in the product card but Add in a separate large bottom dock with repeated order information. Shop's approved product layout puts the purchase control beside price. Wholesale is the source-type difference; not every Offers SKU has this defect.

Expected: one compact identity/price/purchase block on Shop, Wholesale, Visit Store and all applicable Offers/Saved/Recent/Compare entry routes. Price left, bounded Add/stepper right; long price, variant, MOQ or tier information wraps into aligned compact rows below. No empty full-width Add lane, duplicate purchase dock or duplicate totals. Preserve the approved Store/public information grouping and Cart access.

Technical owner: BuyV2ProductView, _WholesaleTradeActionDock and shared purchase row in apps/mobile/lib/ui_v2/buy/buy_v2_views.dart. Reuse the shared control while retaining Wholesale MOQ, quantity increments, stock limits, eligibility, business verification and freight/tax information. Test disabled/Add/stepper states, long labels, large prices, large text and back navigation. Do not make unavailable products purchasable to achieve layout parity.

## F — Compact Cart browsing actions

Observed076: full-width navy Continue browsing / Mool Market31 occupies y330–442, followed by full-width outlined Browse more products y458–554. Products begin only below these, while Review order is another prominent filled action. Source uses an infinite-width FilledButton.tonal with minimum height56 and a second infinite-width OutlinedButton with minimum height44.

Expected: Continue browsing [Store name] and Browse more are quiet, compact secondary actions near the basket context; inline where space permits, wrapping cleanly when necessary. Keep a single visually dominant Review order CTA. Store continuation returns to the correct Store; generic Browse returns to the correct discovery context with existing filter/location state. Hide genuinely redundant actions only when both have the same destination. Preserve touch targets without full-width solid-color slabs.

## G — Premium, coherent Cart through order review

Visual target: calm neutral surfaces, existing navy for the main action/selected state, restrained existing brand accents/gradients, compact aligned text and consistent icon/thumbnail sizes. No new top tabs, competing solid-color panels, repeated meanings or miniature text. Organize the existing screens rather than inventing a new checkout flow.

Indicative content hierarchy (adapts to small screens and long content):

    Cart                 4 products · 6 items
    Existing basket scope selector
    Continue at [Store]       Browse more
    Store / fulfilment context
    [photo] Product · variant       price
            pack / availability     [- qty +]
    Benefits / delivery or collection / bill details
    Optional recommendations, secondary to checkout essentials
    Total                             [Review order]

Keep basket items, benefit validity, fulfilment choice and bill understandable before optional discovery content. Current discovery sections appear before instructions/bill and lengthen the journey; assess collapse/reordering without deleting useful routes. Keep totals and one primary action reachable without covering content or Android navigation. Reuse existing Cart state, address editor, payment chooser and final-review screen. Preserve Store grouping, separate Shop/Wholesale terms, discount/tax/delivery calculations, quantity validation, collection choice and return paths. No fabricated charge, availability, payment success or order confirmation.

Child R6633-D06-G-C1: screenshot078 shows Purchase order reference with stale XYZ in Shop payment choices, although Purchase order is not an offered method and no valid payment is selected. Current view condition checks only session.selectedPayment == 'Purchase order'. Future correction must reconcile selected payment with current basket/available methods and show dependent fields only for an eligible selected option. Retain the existing disabled continuation until selection is valid. Test basket-type changes, returns from checkout, method removal and persistence; never silently choose or submit a payment method.

Future journey matrix: product Add → basket → quantity/edit/remove/undo/empty states → single/mixed Store and Shop/Wholesale baskets → offers/benefits/bill → delivery or collection → address/recipient → eligible payment choice → final review/edit/back → submission pending/error/retry/confirmed order and relevant invoice entry, to the extent the exact provider contract supports it. Unavailable backend/auth/provider steps must remain explicitly blocked/deferred rather than reported as passed. No real transaction is part of current registration. Reuse existing order/invoice work; do not redesign Downloads or Store operations.

For every affected screen: test narrow Android portrait, long product/Store/address text, large amounts, enlarged text, keyboard focus/scroll/dismiss/back, system insets, no hidden last row/action, stable Cart access, route continuity and unchanged totals. Fresh080 shows recipient focus above the keyboard; it does not prove every lower address field or Save control is reachable. Cover those specifically during implementation qualification.

## Bounded implementation and acceptance plan — future, not started

Runtime candidates: existing buy_v2_catalogue.dart, buy_v2_views.dart, buy_v2_session.dart; public contract owner buy_v2_content_contracts.dart only if an actual coordinated gap requires it. Reuse current catalogue/controller/Saved/Cart and checkout tests; select exact test owners when implementation starts. No changes to another worktree, native release controls, policy, unrelated screens, backend or Google integration. Shared Store/admin mapping must be coordinated with its owner.

Order: stabilize A/query behavior; C/D shared controls; E purchase placement; F/G Cart hierarchy/state correctness. B is a separately visible data dependency and must not be hidden by synthetic offers. Inspect each stage for child regressions. Link existing D03 Recent compactness, D04 Cart white strip, D05 missing comparison provider rather than pretending these are newly fixed by D06.

Local acceptance after future authorization: focused widget/controller checks for the actual failures and affected journey transitions, real local Flutter captures for populated/empty/loading/error/Saved/Shop/Wholesale and keyboard states, then show the founder those actual screens. Founder visual approval does not close functional or provider checks. Device acceptance and a fresh APK require the separately authorized build scope. No new tests were run for this documentation-only registration; source must remain identical to the installed candidate.

## Evidence map

- 068/069: Offers and mixed Shop/Wholesale listings; 070/071: timed publisher transitions.
- 072: publisher filter; 073: incorrect Saved popup/scope; 074: Wholesale product and bottom Add dock.
- 075/076: Cart lower/top content and competing browsing actions.
- 077: address choices; 078: payment choices and orphan purchase-reference field.
- 079/080: address editor and recipient keyboard; 081: restored unchanged Cart.

All seven packages and both named children remain OPEN. Evidence registration is complete; implementation, local design approval and future provider/device qualification are not.
