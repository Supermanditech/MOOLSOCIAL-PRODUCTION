$ErrorActionPreference = 'Stop'
$scriptPath = Join-Path (Get-Location) 'scripts/check-codex-subagent-coordination-policy.ps1'
$tokens = $null; $parseErrors = $null
$ast = [Management.Automation.Language.Parser]::ParseFile($scriptPath, [ref]$tokens, [ref]$parseErrors)
if ($parseErrors.Count -ne 0) { throw 'Coordination script parse failed' }
$fn = $ast.Find({param($node) $node -is [Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -ceq 'Test-CursorBuyReadyHistoricalSubject'}, $true)
Invoke-Expression $fn.Extent.Text
$root = 'C:/GUARANTEED OUTCOME/MOOLSOCIAL-WORKTREE-CURSOR-buy-ready-20260921'
$AgentRole = 'primary'; $AgentTask = '/root'; $ProductionLane = 'cursor_ui'; $ProductionPhase = 'handoff'
$ProductionWorkId = 'buy-ready-20260921'; $ProductionTicketId = 'UAW-CURSOR-BUY-READY-20260921'
$branch = 'work/cursor-ui/buy-ready-20260921'; $baseCommit = '635ab9810ba8805104642f8f78512c80fe1b20f5'
$commits = @(& git rev-list --reverse '635ab9810ba8805104642f8f78512c80fe1b20f5..6ba7dc3f2b2d75be7ffdcdb3bfce6ca3090b3ed8')
if ($LASTEXITCODE -ne 0 -or $commits.Count -ne 7) { throw 'Historical inventory failed' }
$checks = 0
foreach ($commit in $commits) {
  $subject = [string](& git show -s --format=%s $commit)
  if (-not (Test-CursorBuyReadyHistoricalSubject $commit $subject)) { throw 'Exact history rejected' }; $checks++
  if (Test-CursorBuyReadyHistoricalSubject $commit ($subject + ' changed')) { throw 'Changed label accepted' }; $checks++
}
$commit = $commits[0]; $subject = [string](& git show -s --format=%s $commit)
if (Test-CursorBuyReadyHistoricalSubject ('0' * 40) $subject) { throw 'Unknown commit accepted' }; $checks++
if (Test-CursorBuyReadyHistoricalSubject $commit.ToUpperInvariant() $subject) { throw 'Noncanonical commit accepted' }; $checks++
foreach ($name in @('root','AgentRole','AgentTask','ProductionLane','ProductionPhase','ProductionWorkId','ProductionTicketId','branch','baseCommit')) {
  $original = (Get-Variable $name).Value
  Set-Variable $name ($original + '-changed')
  if (Test-CursorBuyReadyHistoricalSubject $commit $subject) { throw ('Wrong context accepted: ' + $name) }; $checks++
  Set-Variable $name $original
}
Write-Output "$checks historical-admission positive/negative checks passed; full script parsed."
