# Add to Cart through order completion — frontend visual/workflow tickets

23 September 2026. Founder clarification supersedes provider-first framing of the previous replay report. Registration only: no implementation, APK or backend work. These are nine actionable children of existing R6633-D06-G, not nine unrelated duplicate parent defects. All are OPEN, awaiting implementation authority.

## Purpose and evidence boundary

Actor: consumer, retailer/Wholesale and Bulk buyer purchasing through Shop, Wholesale, Offers or Visit Store. Launch-supporting visual polish plus launch-required validation/navigation repairs. Observable outcome: a compact, clear, consistent purchase journey with every editable field and next action reachable. Backend absence does NOT block frontend ticket registration, layout work or local qualification using existing explicitly labelled review contracts. Live payment, identity, fulfilment and tracking acceptance remain separate.

This specification reviews existing actual r66.33 Redmi screenshots and the recorded 30 route/state checks, not a new device run. Build 2026092202; source 1650a1ddb3bf3672530c8d345d0a5c3e9f475aba; evidence registration baseline 51b69ea1e44a1095feaa070f5ce0d2202c258049. No unexecuted tap, live delivery or provider success is claimed. Screens 127,153,171,079,128,089 were visually re-inspected for this specification. Other numbered references below belong to the preceding archived replay.

## Required order of information and actions

Product/variant and quantity → Cart items and amount → delivery address or Collect at store → eligible payment method and necessary fields → final review → placement result → order progress, invoice and support. Reuse existing stages and routes. Cart's action should describe the actual next stage, rather than imply final review if address/payment still follow. Back/Edit must return to the affected section with choices intact; validation must reveal the field to correct. Review must remain the explicit last check before an order submission. Do not add unnecessary intermediate screens.

Delivery service and timing are platform assigned, not customer-selected slots: MoolSocial Quick Delivery, MoolSocial Scheduled Delivery, MoolSocial Courier Delivery (also scheduled). Show provider-supplied timing separately from service. Preserve the approved Collect at store choice. Do not invent thresholds, availability, live countdowns or readiness.

## Registered child tickets

### R6633-D06-G-V01 — Compact product selection and Cart entry

Observed: Wholesale/Offers retain a bottom Add lane unlike the approved Shop price/Add row (074; existing D06-E). Add/Edit basket can land at recommendations, hiding purchased items (116/158/161/168; D14).

Expected: reuse approved product layout across every entry route; image, public name/variant, price/unit and compact Add/quantity together. Keep MOQ and pack facts adjacent without a separate empty action lane. Preserve quantities and minimum validation. Added item feedback must be visible; Cart entry reveals the affected basket/item. Back returns to originating product/list and scope. Do not duplicate D06-E or D14 implementation.

### R6633-D06-G-V02 — Cart items first; organized compact bill and secondary actions

Observed:171 has a large header, scope panel and two full-width browsing actions before the first item; one Wholesale line repeats pack/price information across blocks. Existing D06-F/G.

Expected hierarchy: compact Cart title/count and scope → item rows grouped only where useful → concise assigned fulfilment summary → optional savings/instructions → aligned amount breakdown → one primary next-step action. Continue browsing/Browse more become small secondary actions, not competing solid panels. Recommendations must not precede purchased items on entry. Item row groups thumbnail, public title/variant, quantity/pack/unit price and subtotal; compact stepper beside price, retained usable tap targets. Use aligned label/value rows for charges, discounts and total; never hide payable components to achieve compactness. Existing illustration remains labelled until an authentic photo exists; do not present it as a verified SKU photograph.

### R6633-D06-G-V03 — Address/collection selection and editable form

Observed:079 has large input rows and introductory spacing;083/102 repeat Store/address/collection instructions and expose an extra sign-in path (D07).

Expected: selected address summary with compact Change/Add action. Form groups recipient name/phone, destination details and optional landmark; persistent labels, appropriate keyboard, logical Next/Done traversal and concise field-level errors. Keep Save reachable by scrolling above keyboard/Android navigation; no giant blank footer. Collection uses one Store identity, concise Store-origin address and small directions action, followed by essential pickup instructions. No duplicate authentication call-to-action in an authenticated journey; actual app identity wiring remains required and must not be bypassed. Changing address/collection must preserve basket and revalidate dependent service/payment state.

### R6633-D06-G-V04 — Payment methods, reference fields and recovery

Observed:103/152/153 show oversized method cards and repeated payment explanations.153 truncates PO helper text above keyboard. Empty reference Review leaves the field offscreen (D15). Cancelled/locked states look selectable and give contradictory instructions (D12). Mixed scope leaks an inapplicable reference (D06-G-C1).

Expected: compact total/charges summary, eligible method rows with a clear selection mark, shared security explanation once where useful. Show method-specific fields directly below selected method, only while applicable. Review validation focuses and reveals the first invalid field; full helper/error text wraps. Preserve draft appropriately when navigating back; discard or exclude stale ineligible data according to existing contract. Pending/cancelled/unavailable states have truthful labels and a clearly available recovery action, without false active controls or payment success. Selecting a valid method advances to review; provider handoff is a distinct later operation. Frontend layout/recovery tests run with labelled existing fixtures; D11 live handoff is separate.

### R6633-D06-G-V05 — Final review as a compact decision summary

Observed:127 dedicates substantial height to back action, three large progress buttons, repeated heading/instruction, address, optional GST and shipment panels.141/154/160 add repeated trade-product sections. Dispatch is labelled Arrives (D13).

Expected: compact progress/header; address or collection summary with Edit; shipment groups showing Store, service, supplied timing and item quantities/amounts once; optional business invoice details only when relevant; selected payment; aligned final bill. Use flexible label/value rows, not dense fixed-width tables that clip on phone. Distinguish dispatch from arrival and absent timing from a promise. One final Place order action with visible payable total. Changing item/address/payment returns to the proper editor and revalidates totals without duplicate lines or stale metadata. Preserve legal disclosures and explicit order consent.

### R6633-D06-G-V06 — Confirmation with a clear next step

Observed:128 has a tall success panel, repeated amounts/items and large stacked invoice/order actions; public names change after order (D16).

Expected: restrained success acknowledgement, reference and total; compact delivery group summary with current state/next expected event; primary View order action, secondary Continue shopping, contextual small Invoice action. Keep public Store/SKU display names consistent while preserving stable IDs and legal identity. Confirmation cannot imply payment settlement or supplier acceptance not returned by the contract. Separate pending/failed/partial outcomes must have equally considered layouts; no fake success to unblock previews.

### R6633-D06-G-V07 — Tracking, order actions and invoice access

Observed:089 repeats packing text in timeline and What happens next; multiple large actions compete.136 stacks status, unavailable-live-update and delivery panels.129/130 invoice metadata is lengthy. Existing D06-G and D10.

Expected: one current status and supplied timing/freshness summary, compact progress timeline, useful next event without repetition; expandable relevant delivery/items details. Show unavailable/stale provider state concisely without an empty map, invented progress or driver. Manage order, Help and Invoice are compact contextual actions, not new top tabs. Preserve central Downloads and order-specific invoice access. Reuse existing invoice contract/new shared format when integrated; do not redesign legal/tax content independently. Download/cancel/failure status must be clear and Android-safe. Live lifecycle is backend-dependent; every frontend state remains locally testable with labelled contract fixtures.

### R6633-D06-G-V08 — Brand, typography and responsive content across the journey

Observed:171/127/153/128/089 show repeated large bold headings, blue/purple bordered blocks, broad solid actions and differently grouped metadata. Register as one cross-cutting polish child, not separate duplicate bugs per screen.

Expected: existing brand tokens, quiet neutral surfaces, restrained accent/gradient for hierarchy, consistent title/body/helper/amount scales, balanced padding and readable contrast. Use emphasis for product, price, total and current status; avoid making every sentence bold or coloured. Organize facts into product, Store, fulfilment, payment and amount groups. Remove repeated meaning, not authoritative terms. Long names/addresses/variants and large amounts wrap naturally; no ellipsis for required decisions/errors. Thumbnails use consistent aspect/fit without misleading crops. Compactness must retain readable text, accessible labels and usable hit areas. Review same shared components across Shop, Wholesale, Bulk, Offers and Visit Store.

### R6633-D06-G-V09 — Keyboard, Android insets, edits and workflow continuity

Confirmed links: D15 offscreen required PO field/truncated helper; D14 wrong Cart viewport; D12 misleading recovery actions.153 shows the focused reference above keyboard and dock hidden; this alone does not prove every field or bottom action safe.079 keyboard-closed form does not prove lower-field reachability. D04 remains the separate white Cart band issue.

Required verification after implementation: every editable quantity/address/phone/PIN/landmark/PO/GST/instruction field actually exposed by existing routes; empty/invalid/long values; focus Next/Done; keyboard open/dismiss/back; validation auto-reveal; cancel preserves prior value; save updates correct section. Scroll to the final field/action with gesture and three-button Android navigation, small height and enlarged text. No obscured buttons, stuck sheet, moving Cart affordance or double navigation. Test invalid→corrected→Review, edit from Review→return, pending→cancel/retry, double tap guard and app resume without duplicate submission. Only display states from existing contracts; backend integration failures are separate from frontend usability failures.

## Per-route acceptance and evidence, not an assertion of completion

| Entry/use case | Frontend route/states to qualify | Existing baseline proof |
| --- | --- | --- |
| Shop consumer | Product/Add, Cart edits, address/collection, payment, review, confirmation, tracking/invoice |115–136,165 |
| Wholesale buyer | MOQ packs, receiving details, eligible method/reference, review and edit return |137–142,171 |
| Bulk buyer | Quantity invalid/cancel, PO required/keyboard, grouped review and missing timing |143–155 |
| Offers retail and trade | Same underlying product/Add/Cart layout, offer eligibility, mixed basket and method changes |074,156–164,177–179 |
| Visit Store | Store-scoped SKU through shared Cart, correct Store/public metadata and review |165–170 |
| All applicable stages | Empty/loading/error/offline/stale, short/long content, keyboard, Android safe area, back/edit, text scale | Acceptance pending; do not claim all permutations tapped |

Run focused tests using the existing shared owners and review fixtures; show actual local Flutter screens after future implementation. Record a child only for a distinct reproducible failure, with route/taps, observed vs expected, evidence and owner. Do not close a visual ticket merely because a provider is deferred. Conversely, frontend fixture success never closes live backend acceptance. Founder visual approval and technical acceptance remain separate.

## Ownership, dependencies and bounded scope

Reuse apps/mobile/lib/ui_v2/buy/buy_v2_views.dart (product, Cart, checkout, confirmation, tracking), apps/mobile/lib/features/buy/buy_v2_session.dart (existing state/validation), and existing buy_v2_invoice.dart and focused checkout/Cart/payment/invoice tests. No new parallel state owner, catalogue, screen flow or backend. Coordinate shared Store/public identity and eligibility changes; do not edit Codex's checkout. Preserve prices, inventory, variant identity, MOQ, payment safeguards and invoice meaning. Public Store data only; private supplier metadata must not leak into UI.

Dependency order for future implementation: shared layout/Cart and field/navigation corrections → address/payment/review → confirmation/tracking/invoice consistency → cross-route local regression and visual review. Providers/auth/Google/logistics run separately when integrated. All nine children and their linked existing defects remain OPEN. This task registers expected outcomes only; no source changes, test rerun, new screenshots or new order/payment actions.
