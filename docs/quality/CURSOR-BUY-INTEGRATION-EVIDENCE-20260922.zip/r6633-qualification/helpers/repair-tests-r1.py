from pathlib import Path
r=Path(r'C:\GUARANTEED OUTCOME\MOOLSOCIAL-WORKTREE-CURSOR-buy-ready-20260921')
root=r/'apps/mobile/test/ui_v2/buy'
def edit(name, edits):
 p=root/('buy_v2_'+name+'.dart'); t=p.read_text(encoding='utf-8-sig')
 for old,new,count in edits:
  assert t.count(old)==count,(name,old[:90],t.count(old),count)
  t=t.replace(old,new)
 p.write_bytes(t.encode('utf-8'))
edit('shopping_settings_test',[
 ("              await tester.ensureVisible(open);\n              await tester.pumpAndSettle();", "              await Scrollable.ensureVisible(tester.element(open), alignment: .4);\n              await tester.pumpAndSettle();\n              expect(open.hitTestable(), findsOneWidget);",2),
])
p=root/'buy_v2_partner_catalogue_test.dart'; t=p.read_text(encoding='utf-8-sig')
start=t.index("          ValueKey('buy-marketplace-trust-ready-${product.id}'),",t.index("SKU M02 ratings seller identity"));end=t.index('        expect(session.selectedProductId',start)
a=t[start:end].replace('buy-marketplace-trust-ready-','buy-product-hero-store-').replace('Mool Market 1 · Manufacturer','Mool Market 1').replace('Mool Market 000001 · Manufacturer','Mool Market 000001')
t=t[:start]+a+t[end:]
start=t.index('          final empty = find.byKey(',t.index('Future<void> checkAdditionalBenefits'))
end=t.index('          expect(session.itemCount, itemCount);', start)
t=t[:start]+'''          // Ready + empty benefits have no promotional panel in the approved
          // compact product layout. Keep the provider and cart assertions.
          expect(session.productBenefitsFor(product), isEmpty);
          expect(find.byKey(ValueKey('buy-product-benefits-empty-${product.id}')), findsNothing);
          expect(find.byKey(ValueKey('buy-product-benefits-ready-${product.id}')), findsNothing);
          expect(find.text('Additional checkout benefits'), findsNothing);
'''+t[end:]
p.write_bytes(t.encode('utf-8'))
p=r/'docs/quality/CURSOR-BUY-INTEGRATION-HANDOFF-20260922.md'
with p.open('a',encoding='utf-8',newline='\n') as f:
 f.write('''
### r66.33 prebuild regression replay — diagnostic run 1

Retained log: `apps/mobile/build/review-candidates/cursor-buy-r6633-20260922/buy1.log`.
Result: 2,407 passed, 27 skipped, 120 failed test cases (many repeat the same assertion at multiple viewport/text sizes). This is not a qualification pass. No APK built or installed.

- Child R6633-C01: public current-location popup intercepted Store procurement address entry. Restore the original address route for Store procurement; retain the public popup. Existing Store return tests must pass unchanged.
- R6633-T01: reconcile superseded product sections, compact Add/Cart, removed empty benefits/Medicine promotion, expandable category sheet and automatic location popup assertions. Preserve actual purchase, cart, Back, Android inset, accessible tap and provider-data checks.
- R6633-T02: custom review/photo provider fixtures must supply explicit eligibility for their named test SKUs. Do not bypass production fail-closed eligibility or use unrelated review-data shortcuts.
- R6633-C02 investigation: Recent card action and narrow-screen delivery controls must be visibly reachable; distinguish an offscreen test tap from a real inaccessible control with focused geometry/tap replay.

Only exact Buy test owners were admitted in the existing worktree registration to repair the APK qualification blocker. No broader rules changed. Backend/Google dependencies remain deferred.
''')
print('Applied first focused repair batch')
