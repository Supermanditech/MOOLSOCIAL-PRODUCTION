from pathlib import Path
import hashlib,json,zipfile,shutil
r=Path(r'C:\GUARANTEED OUTCOME\MOOLSOCIAL-WORKTREE-CURSOR-buy-ready-20260921')
a=r/'apps/mobile/build/review-candidates/cursor-buy-r6633-20260922'
external=Path(__file__).parent
archive=r/'docs/quality/CURSOR-BUY-INTEGRATION-EVIDENCE-20260922.zip'
assert (a/'installed-identity.json').is_file(), 'Archive only after installed identity verification'
replay=json.loads((a/'device-replay.json').read_text(encoding='utf-8-sig'))
assert replay['state']!='not_built_device_replay_pending'
before=hashlib.sha256(archive.read_bytes()).hexdigest()
backup=external/'pre-r6633-evidence-archive.zip'
assert not backup.exists();shutil.copy2(archive,backup)
prefix='r6633-qualification/'
with zipfile.ZipFile(archive) as z:
 originalNames=z.namelist();assert not any(n.startswith(prefix) for n in originalNames)
 originalCrc={n:(z.getinfo(n).CRC,z.getinfo(n).file_size) for n in originalNames}
files=[p for p in a.rglob('*') if p.is_file() and p.suffix.lower() in {'.log','.json','.md','.txt','.png','.xml'}]
helpers=[p for p in external.iterdir() if p.is_file() and p.suffix.lower() in {'.py','.ps1'}]
with zipfile.ZipFile(archive,'a',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(files):z.write(p,prefix+'candidate/'+p.relative_to(a).as_posix())
 for p in sorted(helpers):z.write(p,prefix+'helpers/'+p.name)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 assert all((z.getinfo(n).CRC,z.getinfo(n).file_size)==old for n,old in originalCrc.items())
 assert len(z.namelist())==len(set(z.namelist()))
receipt={'archive':archive.relative_to(r).as_posix(),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'priorSha256':before,'priorEntriesPreserved':len(originalNames),'addedCandidateEvidenceFiles':len(files),'addedHelperFiles':len(helpers),'prefix':prefix,'apkBytesExcluded':'APK and pulled installed copy remain retained in candidate directory; source and receipts are pushed in Git.'}
assert archive.stat().st_size<100*1024*1024, 'Do not push an oversized archive'
(a/'archive-receipt.json').write_bytes((json.dumps(receipt,indent=2)+'\n').encode())
print(json.dumps(receipt))
