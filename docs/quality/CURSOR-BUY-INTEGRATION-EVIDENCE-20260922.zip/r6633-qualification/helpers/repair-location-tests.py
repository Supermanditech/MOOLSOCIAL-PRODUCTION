from pathlib import Path
root=Path(r'C:\GUARANTEED OUTCOME\MOOLSOCIAL-WORKTREE-CURSOR-buy-ready-20260921\apps\mobile\test\ui_v2\buy')
p=root/'buy_v2_partner_catalogue_test.dart';t=p.read_text(encoding='utf-8-sig')
t="import 'buy_v2_qualified_provider_fixture.dart';\n"+t
start=t.index("'R669 area final row clears Android navigation")
end=t.index("'R5 paged published Offers journey",start)
a=t[start:end].replace('R669 area final row clears Android navigation','R669 current location confirmation clears Android navigation')
a=a.replace('            core: core,','            core: core,\n            shoppingAreaSource: TestCurrentLocationSource(\'chennai\', \'Chennai\'),',1)
a=a.replace('buy-catalogue-area-chennai','buy-current-location-confirm')
a=a.replace('expect(bounds.height, greaterThanOrEqualTo(48));','expect(bounds.height, greaterThanOrEqualTo(44));')
t=t[:start]+a+t[end:]
start=t.index("'R5 paged catalogue user actions");end=t.index("'Local cutoff checkout",start)
a=t[start:end].replace('            core: core,','            core: core,\n            shoppingAreaSource: TestCurrentLocationSource(\'mumbai\', \'Mumbai\'),',1)
a=a.replace("          await tester.enterText(field, 'Mum');", "          expect(field, findsNothing);\n          expect(find.byKey(const ValueKey('buy-current-location-result')), findsOneWidget);")
a=a.replace('buy-catalogue-area-mumbai','buy-current-location-confirm')
t=t[:start]+a+t[end:];p.write_bytes(t.encode('utf-8'))
p=root/'buy_v2_session_test.dart';t=p.read_text(encoding='utf-8-sig')
t=t.replace('  final queries = <String>[];', '  Completer<BuyV2ShoppingArea?>? pendingLocation;\n  final queries = <String>[];',1)
start=t.index('final class _R669ShoppingAreas');end=t.index('void r669ShoppingAreaTests',start)
a=t[start:end].replace('    return areas.firstOrNull;', '    return pendingLocation == null ? areas.firstOrNull : await pendingLocation!.future;')
t=t[:start]+a+t[end:]
start=t.index("          final locate = find.byKey(",t.index("'area failure visible without scrolling"));end=t.index('          await tester.binding.handlePopRoute();',start)
t=t[:start]+'''          final failure = find.byKey(const ValueKey('buy-area-lookup-failure'));
          final retry = find.byKey(const ValueKey('buy-area-lookup-retry'));
          final list = find.byKey(const ValueKey('buy-catalogue-area-list'));
          final scroll = find.descendant(of: list, matching: find.byType(Scrollable)).first;
          expect(find.byKey(const ValueKey('buy-catalogue-area-search')), findsNothing);
          for (final inset in [0.0, 120.0]) {
            tester.view.viewInsets = FakeViewPadding(bottom: inset);
            await tester.pumpAndSettle();
            await tester.scrollUntilVisible(failure, 80, scrollable: scroll);
            await Scrollable.ensureVisible(tester.element(failure), alignment: .4);
            await tester.pumpAndSettle();
            expect(failure.hitTestable(), findsOneWidget);
            await tester.scrollUntilVisible(retry, 80, scrollable: scroll);
            await tester.pumpAndSettle();
            expect(retry.hitTestable(), findsOneWidget);
            expect(tester.getRect(retry).bottom, lessThanOrEqualTo(size.height - inset));
            await captureR66Visual(tester, 'r669-area-failure-${size.width}-$scale-$inset');
            await tester.tap(retry);
            await tester.pumpAndSettle();
            expect(failure, findsOneWidget);
            expect(session.catalogueRegionId, originalRegion);
          }
          tester.view.viewInsets = const FakeViewPadding();
          await tester.pumpAndSettle();
'''+t[end:]
t=t.replace("'area failure visible without scrolling $size $scale'", "'area failure and retry remain reachable with insets $size $scale'")
start=t.index("        final search = find.byKey(",t.index("'sheet search keyboard retry selection and Back"));end=t.index('        expect(tester.takeException(), isNull);\n      });',start)
t=t[:start]+'''        expect(source.queries, isEmpty);
        expect(find.byKey(const ValueKey('buy-catalogue-area-search')), findsNothing);
        final result = find.byKey(const ValueKey('buy-current-location-result'));
        final confirm = find.byKey(const ValueKey('buy-current-location-confirm'));
        final list = find.byKey(const ValueKey('buy-catalogue-area-list'));
        Future<void> reveal(Finder target) async {
          await tester.scrollUntilVisible(target, 100,
            scrollable: find.descendant(of: list, matching: find.byType(Scrollable)).first);
          await Scrollable.ensureVisible(tester.element(target), alignment: .4);
          await tester.pumpAndSettle();
          expect(target.hitTestable(), findsOneWidget);
        }
        expect(result, findsOneWidget);
        expect(find.descendant(of: result, matching: find.text(area.label)), findsOneWidget);
        expect(find.byKey(const ValueKey('buy-current-location-map')), findsOneWidget);
        tester.view.viewInsets = const FakeViewPadding(bottom: 230);
        await tester.pumpAndSettle();
        await reveal(confirm);
        expect(tester.getRect(confirm).bottom, lessThanOrEqualTo(568 - 230));
        await captureR66Visual(tester, 'r669-current-location-inset-$scale');
        await tester.tap(confirm);
        tester.view.viewInsets = const FakeViewPadding();
        await tester.pumpAndSettle();
        expect(session.catalogueRegionId, area.regionId);
        expect(list, findsNothing);
        source.failure = BuyV2ShoppingAreaFailure.permissionDenied;
        await tester.tap(find.text('Choose shopping area'));
        await tester.pumpAndSettle();
        final retry = find.byKey(const ValueKey('buy-area-lookup-retry'));
        await reveal(retry);
        expect(session.catalogueRegionId, area.regionId);
        source.failure = null;
        await tester.tap(retry);
        await tester.pumpAndSettle();
        expect(result, findsOneWidget);
        await tester.binding.handlePopRoute();
        await tester.pumpAndSettle();
        source.pendingLocation = Completer<BuyV2ShoppingArea?>();
        await tester.tap(find.text('Choose shopping area'));
        await tester.pump(const Duration(milliseconds: 400));
        expect(find.text('Finding your current location...'), findsOneWidget);
        await tester.binding.handlePopRoute();
        await tester.pump(const Duration(milliseconds: 500));
        source.pendingLocation!.complete(area);
        await tester.pumpAndSettle();
        expect(list, findsNothing);
        expect(session.catalogueRegionId, area.regionId);
'''+t[end:]
t=t.replace("'sheet search keyboard retry selection and Back $scale'", "'current location inset retry confirmation and late Back $scale'")
p.write_bytes(t.encode('utf-8'))
print('Location provider fixture and UI tests reconciled')
