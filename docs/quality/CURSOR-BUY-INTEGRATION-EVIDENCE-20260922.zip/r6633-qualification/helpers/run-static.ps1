param([Parameter(Mandatory)][ValidateSet('protected','backend','egress','brand','ui-locks','coverage','backend-self','egress-self','unregistered-source')][string]$Check,[Parameter(Mandatory)][string]$SourceCommit,[string]$Attempt='r1')
$ErrorActionPreference = 'Stop'
$taskRoot = 'C:\GUARANTEED OUTCOME\MOOLSOCIAL-WORKTREE-CURSOR-buy-ready-20260921'
Set-Location $taskRoot
$artifactRoot = Join-Path $taskRoot 'apps/mobile/build/review-candidates/cursor-buy-r6633-20260922'
$log = Join-Path $artifactRoot "$Check-$Attempt.log"
$resultPath = Join-Path $artifactRoot "$Check-$Attempt.result.json"
if ((Test-Path -LiteralPath $log) -or (Test-Path -LiteralPath $resultPath)) { throw 'Existing attempt is immutable.' }
$started = [DateTimeOffset]::Now.ToString('o')
$code = 0
try {
  & {
    switch ($Check) {
      protected { & .\scripts\check-buy-protected-baseline.ps1 -IntegratedReviewSourceCommit $SourceCommit }
      backend { & .\scripts\check-buy-backend-contract-boundary.ps1 -IntegratedReviewSourceCommit $SourceCommit }
      egress { & .\scripts\check-buy-data-egress-boundary.ps1 -IntegratedReviewSourceCommit $SourceCommit }
      brand { & .\scripts\check-brand-integrity.ps1 -IntegratedReviewSourceCommit $SourceCommit }
      ui-locks { & .\scripts\check-approved-ui-locks.ps1 }
      coverage { & .\scripts\check-approved-integration-commit-coverage.ps1 -RepositoryRoot $taskRoot -ManifestPath (Join-Path $taskRoot 'config/approved-integration-commit-coverage-20260901.json') -CandidateHead HEAD }
      backend-self { & .\scripts\check-buy-backend-contract-boundary.ps1 -SelfTest }
      egress-self { & .\scripts\check-buy-data-egress-boundary.ps1 -SelfTest }
      unregistered-source {
        $rejected = $false
        try { & .\scripts\check-buy-protected-baseline.ps1 -IntegratedReviewSourceCommit '3959b3c23ba09f66397b74313b8ddfb90c761442' }
        catch { $rejected = $_.Exception.Message.Contains('Integrated review source rejected:') }
        if (-not $rejected) { throw 'Unregistered source was not rejected.' }
        Write-Output 'PASS: unregistered reconciliation source rejected; exact source pin remains required.'
      }
    }
    if (-not $?) { throw "$Check gate failed." }
  } *> $log
} catch {
  $code = 1
  $_ | Out-String | Add-Content -LiteralPath $log
}
[ordered]@{check=$Check; source=$SourceCommit; started=$started; ended=[DateTimeOffset]::Now.ToString('o'); exitCode=$code; log=$log} | ConvertTo-Json | Set-Content -LiteralPath $resultPath -Encoding utf8
Get-Content -LiteralPath $log -Tail 5
Write-Output "RESULT check=$Check exitCode=$code"
exit $code
