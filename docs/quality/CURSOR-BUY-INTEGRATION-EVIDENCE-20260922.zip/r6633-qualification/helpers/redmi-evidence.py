import sys,subprocess,json,datetime,xml.etree.ElementTree as ET
from pathlib import Path
adb=r'C:\Users\jisal\AppData\Local\Android\Sdk\platform-tools\adb.exe'
serial='TG8HCYTGGQT885OF'
root=Path(r'C:\GUARANTEED OUTCOME\MOOLSOCIAL-WORKTREE-CURSOR-buy-ready-20260921\apps\mobile\build\review-candidates\cursor-buy-r6633-20260922\redmi')
root.mkdir(exist_ok=True)
name=sys.argv[1];assert name.replace('-','').replace('_','').isalnum()
png=root/(name+'.png');xml=root/(name+'.xml');receipt=root/(name+'.json')
assert not any(p.exists() for p in [png,xml,receipt]), 'Never overwrite capture evidence'
def run(*args):return subprocess.run([adb,'-s',serial,*args],capture_output=True,check=True).stdout
remote='/sdcard/cursor-r6633-'+name+'.xml'
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
dump=run('shell','uiautomator','dump',remote).decode(errors='replace')
nodes=None
if 'dumped' in dump.lower():
 run('pull',remote,str(xml));nodes=ET.fromstring(xml.read_bytes())
 assert nodes.tag=='hierarchy'
png.write_bytes(run('exec-out','screencap','-p'))
assert png.read_bytes().startswith(b'\x89PNG\r\n\x1a\n')
receipt.write_text(json.dumps({'device':serial,'startedAt':started,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'png':str(png),'xml':str(xml) if nodes is not None else None,'uniqueRemote':remote,'dumpResult':dump,'hierarchyAvailable':nodes is not None},indent=2)+'\n')
print(png)
if nodes is None:
 print('Hierarchy unavailable during active UI; inspect actual screenshot. No old XML reused.')
 sys.exit(0)
for n in nodes.iter('node'):
 label=n.get('text') or n.get('content-desc')
 if label: print(ascii(label),n.get('bounds'),'click='+str(n.get('clickable')))
