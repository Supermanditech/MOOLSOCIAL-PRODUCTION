from pathlib import Path
import difflib, json, sys
r=Path(r'C:\GUARANTEED OUTCOME\MOOLSOCIAL-WORKTREE-CURSOR-buy-ready-20260921')
out=Path(__file__).parent/'proposed'
out.mkdir(exist_ok=True)
name=sys.argv[1]
p=r/'apps/mobile/test/ui_v2/buy'/name
before=p.read_text(encoding='utf-8-sig')
t=before
def replace(old,new,count=1):
    global t
    assert t.count(old)==count,(name,old[:100],t.count(old),count)
    t=t.replace(old,new)
if name=='buy_v2_category_sheet_style_motion_test.dart':
    replace("expect(field.decoration?.label, isA<ExcludeSemantics>());", "expect(field.decoration?.label, isNull);\n      final searchNode = tester.getSemantics(\n        find.byKey(const ValueKey('buy-category-search-semantics')),\n      );\n      expect(searchNode.label, 'Category search');\n      expect(searchNode.hint, 'Find a category');")
    replace("expect(find.text('Category search'), findsOneWidget);", "expect(find.text('Category search'), findsNothing);")
    replace("""      expect(
        field.decoration?.floatingLabelBehavior,
        FloatingLabelBehavior.always,
      );
""", "")
elif name=='buy_v2_discovery_refinement_test.dart':
    replace("""          final top = await readScrollBall(
""", """          // The approved sheet expands first; then its content scrolls.
          await tester.drag(
            find.byKey(const ValueKey('buy-category-drag-handle')),
            const Offset(0, -800),
          );
          await tester.pumpAndSettle();
          final sheet = tester.widget<DraggableScrollableSheet>(
            find.byType(DraggableScrollableSheet),
          );
          expect(sheet.controller!.size, closeTo(sheet.maxChildSize, .01));
          final top = await readScrollBall(
""")
elif name=='buy_v2_order_resolution_test.dart':
    replace("for (final destination in ['shop', 'wholesale', 'medicine']) {", "expect(find.byKey(const ValueKey('buy-promotion-orders-medicine')), findsNothing);\n        for (final destination in ['shop', 'wholesale']) {")
elif name=='buy_v2_order_progress_test.dart':
    replace("ValueKey('buy-product-hero-delivery-${product.id}'),", "ValueKey('buy-automatic-fulfilment-${product.id}'),")
    replace("expect(artworkWithin(hero), findsOneWidget);", """expect(
              find.descendant(of: hero, matching: find.text(
                buyV2FulfilmentModeLabel(session.fulfilmentModeFor(product)),
              )), findsOneWidget,
            );""")
elif name=='buy_v2_prescription_match_continuity_test.dart':
    replace("""    await tester.tap(
      find.byKey(const ValueKey('buy-product-primary-m-telmisartan-40')),
    );""", """    final add = find.byKey(const ValueKey('buy-product-primary-m-telmisartan-40'));
    final productScroll = find.descendant(
      of: find.byKey(const PageStorageKey('buy-product-m-telmisartan-40')),
      matching: find.byType(Scrollable),
    ).first;
    await tester.scrollUntilVisible(add, 160, scrollable: productScroll);
    await Scrollable.ensureVisible(tester.element(add), alignment: .4);
    await tester.pumpAndSettle();
    expect(add.hitTestable(), findsOneWidget);
    await tester.tap(add);""")
elif name=='buy_v2_product_content_test.dart':
    replace("""            of: hero,
            matching: find.textContaining(
              'Delivery time confirmed at checkout',""", """            of: find.byKey(ValueKey('buy-automatic-fulfilment-$productId')),
            matching: find.textContaining(
              'Delivery time confirmed at checkout',""")
elif name=='buy_v2_product_compact_action_test.dart':
    replace("expect(tester.getSize(slot), const Size(148, 44));", "expect(tester.getSize(slot), Size(destination == BuyV2Destination.shop ? 88 : 148, 44));")
    replace("""    expect(slotSizeBefore.width, greaterThanOrEqualTo(120));
    expect(tester.getSize(slot), slotSizeBefore);
    expect(tester.getTopLeft(slot), slotOriginBefore);
    expect(tester.getSize(stepper).width, slotSizeBefore.width);
    expect(tester.getSize(stepper).height, 44);
""", """    expect(slotSizeBefore.width, 88);
    expect(tester.getSize(slot).width, inInclusiveRange(120, 170));
    expect(tester.getSize(slot).height, slotSizeBefore.height);
    expect(tester.getTopRight(slot), slotOriginBefore + Offset(slotSizeBefore.width, 0));
    expect(tester.getSize(stepper), tester.getSize(slot));
""")
elif name=='buy_v2_scoped_cart_checkout_dock_continuity_test.dart':
    replace("""              findsNothing,
              reason: 'The seeded empty page has free space for the Cart.',""", """              findsOneWidget,
              reason: 'Public Buy keeps Cart fixed in its navigation rail.',""")
    replace("""                inInclusiveRange(
                  5,
                  firstDelta.distance + nextDelta.distance + 1,
                ),
                reason:
                    'Cart must follow the new finger movement from its displayed position.',""", """                closeTo(0, .01),
                reason: 'The fixed Cart must not move with content or gestures.',""")
else:
    raise SystemExit('Unsupported exact owner')
assert before!=t
target=out/name
assert not target.exists(), 'Preserve previous proposal'
target.write_bytes(t.encode('utf-8'))
rel=p.relative_to(r).as_posix()
patch=''.join(difflib.unified_diff(before.splitlines(True),t.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
(out/(name+'.patch')).write_bytes(patch.encode('utf-8'))
print(json.dumps({'owner':rel,'patch':str(out/(name+'.patch'))}))
