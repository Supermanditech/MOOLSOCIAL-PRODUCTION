from pathlib import Path
import json
r=Path(r'C:\GUARANTEED OUTCOME\MOOLSOCIAL-WORKTREE-CURSOR-buy-ready-20260921')
a=r/'apps/mobile/build/review-candidates/cursor-buy-r6633-20260922'
source=Path(r'C:\GUARANTEED OUTCOME\outputs\buy-next-redmi-reconciliation-20260922\APK-INCLUSION-REPORT.md').read_text(encoding='utf-8-sig')
rows=[]
for line in source.splitlines():
 parts=[v.strip() for v in line.split('|')]
 if len(parts)==6 and parts[1].isdigit():
  rows.append({'number':int(parts[1]),'ticket':parts[2],'scope':parts[3],'firstSourceCommit':parts[4],'included':True,'deviceStatus':'pending','evidence':[]})
assert len(rows)==22
report={'candidate':'UAW-CURSOR-BUY-R6633-20260922','plannedVersion':'1.0.0-r66.33-cursorreview','sourceHead':'1650a1ddb3bf3672530c8d345d0a5c3e9f475aba','state':'not_built_device_replay_pending','scope':'Fresh isolated review APK and focused confirmation of the 22 reconciled frontend outcomes; no backend integration or new feature implementation.', 'preinstall':{'version':'1.0.0-r66.32-cursorreview','sha256':'F74ADCD10DE5A5DFA3F6A29F024484DCB8CAF294FB0682C01680EB7190F2CF8A','capture':'redmi/000-preinstall-r6632-state.png','visibleCartCount':6,'visibleCartTotal':'INR 14,692','visibleHistoricalDeliveryCount':12}, 'tickets':rows, 'deferred':['Authentic Store publication/photos/address and verified physical pin','Live authentication, payment/provider completion','Live Google API and fleet/serviceability integration'], 'newDeviceFindings':[]}
p=a/'device-replay.json';assert not p.exists();p.write_bytes((json.dumps(report,indent=2)+'\n').encode())
print('Prepared 22-row device replay register; all physical results pending.')
