from pathlib import Path
import json, subprocess, hashlib
r=Path(r'C:\GUARANTEED OUTCOME\MOOLSOCIAL-WORKTREE-CURSOR-buy-ready-20260921')
a=r/'apps/mobile/build/review-candidates/cursor-buy-r6633-20260922'
statepath=a/'apk-state.json';state=json.loads(statepath.read_text(encoding='utf-8-sig'))
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()
assert head==state['candidate']['head']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=r)
remote=subprocess.check_output(['git','ls-remote','--heads','origin','refs/heads/'+state['candidate']['branch']],cwd=r,text=True).split()[0]
assert remote==head
for run in ['buy2','buy3']:
 result=json.loads((a/(run+'.result.json')).read_text(encoding='utf-8-sig'))
 assert result['exitCode']==0 and result['head']==head,(run,result)
 log=(a/(run+'.log')).read_text(encoding='utf-8-sig')
 assert 'All tests passed!' in log and 'Some tests failed.' not in log
for check in ['protected','backend','egress','brand','ui-locks','coverage','backend-self','egress-self','unregistered-source']:
 result=json.loads((a/(check+'-r2.result.json')).read_text(encoding='utf-8-sig'))
 assert result['exitCode']==0,(check,result)
for log,marker in [('clean-support.log','Flutter tracked-support cleanliness guard passed.'),('wrapper-profile.log','CURSOR_UI_REVIEW_BUILD_PROFILE_TESTS_PASSED'),('build-foundation.log','Public-auth sideload build controls passed:'),('format.log','0 changed'),('regression-memory.log','passed')]:
 assert marker in (a/log).read_text(encoding='utf-8-sig'),log
analysis=json.loads((a/'analysis-final.result.json').read_text(encoding='utf-8-sig'));assert analysis['exitCode']==0 and analysis['head']==head
manifest=r/state['source']['manifestPath']
assert hashlib.sha256(manifest.read_bytes()).hexdigest().upper()==state['source']['manifestSha256']
for row in manifest.read_text().splitlines():
 sha,path=row.split('  ',1)
 assert hashlib.sha256((r/path).read_bytes()).hexdigest().upper()==sha,path
report=a/'PREBUILD.md';assert not report.exists()
report.write_text(f'''# r66.33 isolated Redmi prebuild

Founder authority: “if git is safe then move ahead with redme apk”.
Branch `{state['candidate']['branch']}`; HEAD and live remote `{head}`.
All 22 post-r66.32 outcomes and the procurement-return repair are included.
Source manifest: {state['source']['fileCount']} files; `{state['source']['manifestSha256']}`.
Both full Buy runs (`buy2`, `buy3`) passed on this HEAD. Failed diagnostic
runs remain intact. Format passed; analysis has no errors/warnings and eight
existing informational brace-style notices. Source/boundary/brand/UI locks,
18-tip history, negative fixtures, wrapper isolation and support restoration pass.

Predecessor r66.32 APK remains retained; device hash was verified as
F74ADCD10DE5A5DFA3F6A29F024484DCB8CAF294FB0682C01680EB7190F2CF8A.
Existing startup regression memory gate and build-foundation receipts pass.
This authorization is for one fresh debug CursorUiReview build/install only,
with installed-checksum verification. Production promotion and live backend,
authentication/payment and Google provider acceptance remain unqualified.
Postbuild checks remain pending. Review boundary exceptions remain documented
in backend-r2.log; this is not production release acceptance.
''',encoding='utf-8')
prefix=a.relative_to(r).as_posix()+'/'
gates={
 'branch-head':['PREBUILD.md'], 'source-manifest':['source-manifest.txt','source-seal.json'],
 'format-analysis':['format.log','analysis-final.log','analysis-final.result.json'],
 'focused-tests':['focused-r1.log','focused-r2.log','focused-r3.log','focused-r4.log','buy2.log','buy3.log'],
 'positive-release-gates':[c+'-r2.log' for c in ['protected','backend','egress','brand','ui-locks','coverage','backend-self','egress-self','unregistered-source']],
 'protected-boundary-disposition':['backend-r2.log','egress-r2.log','PREBUILD.md'],
 'rejected-candidate-preserved':['buy1.log','PREBUILD.md'],
 'startup-config-regression-registered':['regression-memory.log','build-foundation.log'],
 'buy-regression-1':['buy2.log','buy2.result.json'], 'buy-regression-2':['buy3.log','buy3.result.json'],
 'clean-state-regression':['clean-support.log'], 'wrapper-self-test':['build-foundation.log','wrapper-profile.log'],
 'package-isolation':['wrapper-profile.log']}
state['preBuildGates']=[{'id':k,'state':'passed','evidence':[prefix+f for f in files]} for k,files in gates.items()]
state['preBuildValidation']={'state':'passed','evidence':prefix+'PREBUILD.md'}
state['machineState']='prebuild_passed';state['buildAuthorization']='approved_for_one_build'
state['premiumMotionPolicy']['state']='host_checks_passed_Redmi_pending_founder_recurring_name_exception_recorded'
statepath.write_bytes((json.dumps(state,indent=2)+'\n').encode())
print(json.dumps({'candidate':state['candidate'],'source':state['source'],'state':state['machineState']}))
