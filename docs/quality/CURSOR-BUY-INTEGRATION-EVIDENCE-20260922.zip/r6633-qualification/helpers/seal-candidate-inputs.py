from pathlib import Path
import hashlib,json,subprocess
r=Path(r'C:\GUARANTEED OUTCOME\MOOLSOCIAL-WORKTREE-CURSOR-buy-ready-20260921')
a=r/'apps/mobile/build/review-candidates/cursor-buy-r6633-20260922'
def git(*args): return subprocess.check_output(['git',*args],cwd=r)
assert not git('status','--porcelain'), 'Seal only clean Git'
head=git('rev-parse','HEAD').decode().strip()
roots=['apps/mobile/lib','apps/mobile/assets','apps/mobile/android','apps/mobile/ios','apps/mobile/packages','apps/mobile/test','apps/mobile/integration_test','apps/mobile/test_driver','apps/mobile/pubspec.yaml','apps/mobile/pubspec.lock','backend','contracts','packages']
paths={p.decode() for p in git('ls-files','--cached','--others','--exclude-standard','-z','--',*roots).split(b'\0') if p}
prior=r/'apps/mobile/build/review-candidates/cursor-buy-post-redmi-20260922-r1/source-manifest-final.txt'
paths.update(line.split('  ',1)[1] for line in prior.read_text(encoding='utf-8-sig').splitlines())
paths.update(['scripts/check-buy-backend-contract-boundary.ps1','scripts/check-buy-data-egress-boundary.ps1','config/codex-subagent-coordination-policy.json','scripts/check-codex-subagent-coordination-policy.ps1'])
manifest=a/'source-manifest.txt'; assert not manifest.exists()
rows=[hashlib.sha256((r/p).read_bytes()).hexdigest().upper()+'  '+p for p in sorted(paths)]
manifest.write_bytes(('\n'.join(rows)+'\n').encode())
source={'manifestPath':manifest.relative_to(r).as_posix(),'manifestSha256':hashlib.sha256(manifest.read_bytes()).hexdigest().upper(),'fileCount':len(rows)}
statepath=a/'apk-state.json'; state=json.loads(statepath.read_text(encoding='utf-8-sig'))
state['source']=source;state['candidate']['head']=head
old=json.loads((r/'docs/quality/CURSOR-BUY-R6632-APK.json').read_text(encoding='utf-8-sig'))
motion=old['premiumMotionPolicy'];motion['candidateContract']='docs/quality/CURSOR-BUY-INTEGRATION-HANDOFF-20260922.md';motion['disposition']=motion['candidateContract'];motion['state']='qualification_pending_Redmi_pending_founder_recurring_name_exception_recorded'
state['premiumMotionPolicy']=motion
statepath.write_bytes((json.dumps(state,indent=2)+'\n').encode())
seal={'head':head,'sourceReviewPin':'02369e96a293e4588cca06efad17a02bf53470a8','source':source,'priorInstalledVersion':'1.0.0-r66.32-cursorreview','postApkTicketOutcomes':22,'limitations':['Isolated frontend review only','Store mapping and live Google/backend integration deferred'],'state':'frozen_inputs_full_regression_pending'}
(a/'source-seal.json').write_bytes((json.dumps(seal,indent=2)+'\n').encode())
print(json.dumps(seal))
