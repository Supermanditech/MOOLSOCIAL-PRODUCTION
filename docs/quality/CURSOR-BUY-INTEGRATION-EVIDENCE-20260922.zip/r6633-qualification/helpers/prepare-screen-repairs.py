from pathlib import Path
root=Path(r'C:\GUARANTEED OUTCOME\MOOLSOCIAL-WORKTREE-CURSOR-buy-ready-20260921\apps\mobile\test\ui_v2\buy')
out=Path(__file__).parent/'proposed-r2';out.mkdir(exist_ok=True)
name='buy_v2_screen_test.dart'; t=(root/name).read_text(encoding='utf-8-sig')
def replace(old,new,count=1):
 global t
 assert t.count(old)==count,(old[:90],t.count(old),count)
 t=t.replace(old,new)
replace("import 'dart:async';", "import 'dart:async';\n\nimport 'buy_v2_qualified_provider_fixture.dart';")
replace("'category glass ends above the dock with compact heading and close'", "'category modal reaches the safe bottom with compact heading and close'")
replace("      final dock = tester.getRect(\n        find.byKey(const Key('moolsocial-compact-destination-rail')),\n      );\n      expect((surface.bottom - dock.top).abs(), lessThanOrEqualTo(24));", "      expect(surface.bottom, closeTo(tester.view.physicalSize.height / tester.view.devicePixelRatio - tester.view.viewPadding.bottom / tester.view.devicePixelRatio, 1));")
replace("    expect(find.text('Order details'), findsOneWidget);", "    expect(find.byKey(ValueKey('buy-wholesale-trade-decision-${product.id}')), findsOneWidget);")
start=t.index("  testWidgets('add confirmation is owned")
end=t.index("  testWidgets('R66 cart drag accumulates",start)
a=t[start:end]
a=a.replace("'buy-cart-acknowledgement'", "'buy-cart-navigation-button'",1)
a=a.replace("    expect(tester.getSize(miniCart).height, 48);\n    expect(tester.getSize(miniCart).width, inInclusiveRange(88, 132));", "    expect(tester.getSize(miniCart), const Size(44, 44));")
a=a.replace("      find.byKey(const ValueKey('buy-mini-cart-transparent-overlay')),\n      findsOneWidget,", "      find.byKey(const ValueKey('buy-cart-navigation-button')),\n      findsOneWidget,")
s=a.index('    expect(\n      tester\n          .widget<BuyV2FiniteValueTransition>'); e=a.index('    await tester.pump(const Duration(milliseconds: 2700));',s)
a=a[:s]+'''    expect(find.descendant(of: miniCart, matching: find.text('1')), findsOneWidget);
    expect(tester.getSemantics(miniCart).label, contains('1 item'));
    expect(tester.getSemantics(miniCart).label, contains(buyV2Money(product.price)));
'''+a[e:]
s=a.index('    expect(\n      tester\n          .widget<BuyV2FiniteValueTransition>');e=a.index('    final initialRect',s)
a=a[:s]+'''    expect(tester.getSemantics(miniCart).label, contains('1 item ready'));

'''+a[e:]
a=a.replace('    expect(movedRect.left, lessThan(initialRect.left));\n    expect(movedRect.top, lessThan(initialRect.top));','    expect(movedRect, initialRect);')
t=t[:start]+a+t[end:]
replace('R66 cart drag accumulates every pointer update between frames','R66 fixed Cart ignores repeated pointer movement and still opens')
replace('closeTo(before.dx - 40, .1)', 'closeTo(before.dx, .1)')
replace('closeTo(before.dy - 60, .1)', 'closeTo(before.dy, .1)')
start=t.index("'RV6 D011 $mode content preserves unique facts"); end=t.index("  testWidgets('all six recovery states",start)
a=t[start:end]
s=a.index('              final compliance = find.byKey('); e=a.index('              for (final heading',s)
a=a[:s]+'''              expect(tester.getSize(content).height, 0,
                reason: 'Duplicate-only content must take no vertical space.');
'''+a[e:]
a=a.replace("            expect(find.text('Product and pack information'), findsOneWidget);", "            expect(find.text('Product and pack information'), product.compliance != null || product.mrp != null ? findsOneWidget : findsNothing);")
t=t[:start]+a+t[end:]
start=t.index("'RV6 D019 minimize restores delivery identity");end=t.index("'RV6 D020",start)
a=t[start:end]
anchor="      final artwork = find.byKey("
s=a.index(anchor)
a=a[:s]+'''      // A fresh app must not activate historical review orders.
      expect(find.byKey(const ValueKey('buy-delivery-compact-artwork')), findsNothing);
      final deliverySession = _R6633ActiveDeliveries(core: BuySession());
      addTearDown(deliverySession.dispose);
      await tester.pumpWidget(app(deliverySession, textScale: scale));
      await tester.pumpAndSettle();
'''+a[s:]
t=t[:start]+a+t[end:]
start=t.index("'RV6 D022 area chooser retains visible selection");end=t.index('  final d018Cases',start)
a=t[start:end]
a=a.replace('      final session = BuyV2Session(', "      final location = TestCurrentLocationSource('jaipur', 'Jaipur');\n      final session = BuyV2Session(",1)
a=a.replace('        core: BuySession(),','        core: BuySession(),\n        shoppingAreaSource: location,',1)
s=a.index("      for (final id in ['jaipur', null]) {"); e=a.index('      expect(tester.takeException(), isNull);',s)
a=a[:s]+'''      for (final region in ['jaipur', 'jodhpur']) {
        location.area = BuyV2ShoppingArea(regionId: region,
          googlePlaceId: 'test-$region', label: region, countryCode: 'IN');
        unawaited(showBuyV2CatalogueArea(tester.element(find.byType(BuyV2Screen)), session));
        await tester.pumpAndSettle();
        final confirm = find.byKey(const ValueKey('buy-current-location-confirm'));
        await Scrollable.ensureVisible(tester.element(confirm), alignment: .5);
        await tester.pumpAndSettle();
        expect(confirm.hitTestable(), findsOneWidget);
        await tester.tap(confirm);
        await tester.pumpAndSettle();
        expect(session.catalogueRegionId, region);
        unawaited(showBuyV2CatalogueArea(tester.element(find.byType(BuyV2Screen)), session));
        await tester.pumpAndSettle();
        final result = find.byKey(const ValueKey('buy-current-location-result'));
        expect(find.descendant(of: result, matching: find.text(region)), findsOneWidget);
        expect(find.byKey(const ValueKey('buy-catalogue-area-search')), findsNothing);
        await captureR66Visual(tester, 'rv6-d022-current-$region-text-$scale');
        await tester.binding.handlePopRoute();
        await tester.pumpAndSettle();
        expect(session.selectedAddress.id, address);
        expect(session.catalogueRegionId, region);
      }
'''+a[e:]
t=t[:start]+a+t[end:]
start=t.index("'Wholesale and Bulk provider storefront keeps Cart on SKU depth")
a=t[start:]
a=a.replace("expect(find.text('Bulk delivery'), findsOneWidget);", "expect(find.descendant(of: find.byKey(ValueKey('buy-automatic-fulfilment-${product.id}')), matching: find.text('Bulk delivery')), findsOneWidget);",1)
t=t[:start]+a
t+='''
class _R6633ActiveDeliveries extends BuyV2Session {
  _R6633ActiveDeliveries({required super.core});
  @override
  List<BuyV2Order> get activeDeliveryOrders => orders
    .where((o) => o.collection == null && o.destination != BuyV2Destination.medicine && !orderIsCompleted(o))
    .toList(growable: false);
}
'''
(out/name).write_bytes(t.encode('utf-8'))
print('Prepared screen test revisions')
