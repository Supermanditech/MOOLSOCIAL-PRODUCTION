from pathlib import Path
p=Path(r'C:\GUARANTEED OUTCOME\MOOLSOCIAL-WORKTREE-CURSOR-buy-ready-20260921\apps\mobile\test\ui_v2\buy\buy_v2_scoped_cart_checkout_dock_continuity_test.dart')
t=p.read_text(encoding='utf-8-sig')
t=t.replace("          await revealClear(-140);\n          final cart", "          await revealClear(-140);\n          await Scrollable.ensureVisible(tester.element(heading), alignment: .4);\n          await tester.pumpAndSettle();\n          expect(heading.hitTestable(), findsOneWidget);\n          expect(clear.hitTestable(), findsOneWidget);\n          final cart",1)
assert t.count("buy-product-benefits-ready-${product.id}")==2
t=t.replace("buy-product-benefits-ready-${product.id}","buy-automatic-fulfilment-${product.id}")
start=t.index("'R664 compact order choices");end=t.index("'R664 order choices remain reachable with keyboard",start)
a=t[start:end]
a=a.replace("        expect(toggle.hitTestable(), findsOneWidget);", "        await Scrollable.ensureVisible(tester.element(toggle), alignment: 1);\n        await tester.pumpAndSettle();\n        expect(toggle.hitTestable(), findsOneWidget);",1)
a=a.replace("        await tester.tap(toggle);", "        await Scrollable.ensureVisible(tester.element(toggle), alignment: 1);\n        await tester.pumpAndSettle();\n        expect(toggle.hitTestable(), findsOneWidget);\n        await tester.tap(toggle);")
t=t[:start]+a+t[end:]
start=t.index("'R664 order choices remain reachable with keyboard");end=t.index("  for (final mixed",start)
a=t[start:end].replace('R664 order choices remain reachable with keyboard','R664 search hides delivery controls even with an active order and keyboard')
s=a.index('      expect(toggle.hitTestable(), findsOneWidget);');e=a.index('      await tester.pumpWidget(const SizedBox.shrink());',s)
a=a[:s]+'''      expect(toggle, findsNothing);
      expect(find.byKey(const ValueKey('buy-quick-delivery-choices-scroll')), findsNothing);
      expect(session.activeDeliveryOrders, isNotEmpty);
      expect(find.byKey(const ValueKey('buy-search-field')), findsOneWidget);
      await capture(tester, 'r664-active-delivery-hidden-in-search-$size');
      expect(session.view, BuyV2View.catalogue);
'''+a[e:]
t=t[:start]+a+t[end:]
out=Path(__file__).parent/'proposed-r2'/p.name
out.write_bytes(t.encode('utf-8'))
print('Prepared fixed Cart, search fleet exclusion and content visibility tests')
