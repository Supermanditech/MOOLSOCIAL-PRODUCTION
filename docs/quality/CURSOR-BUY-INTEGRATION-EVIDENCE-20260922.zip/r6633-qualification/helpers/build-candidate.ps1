param([switch]$Preflight,[Parameter(Mandatory)][string]$Attempt)
$ErrorActionPreference='Stop'
$taskRoot='C:\GUARANTEED OUTCOME\MOOLSOCIAL-WORKTREE-CURSOR-buy-ready-20260921'
Set-Location $taskRoot
$artifactRelative='apps/mobile/build/review-candidates/cursor-buy-r6633-20260922'
$artifactRoot=Join-Path $taskRoot $artifactRelative
$statePath=Join-Path $artifactRoot 'apk-state.json'
$state=Get-Content -LiteralPath $statePath -Raw | ConvertFrom-Json
$log=Join-Path $artifactRoot "$Attempt.log"
$result=Join-Path $artifactRoot "$Attempt.result.json"
if ((Test-Path $log) -or (Test-Path $result)) { throw 'Preserve earlier attempt' }
if ($state.buildAuthorization -cne 'approved_for_one_build') { throw 'Candidate is not qualified and authorized' }
$started=[DateTimeOffset]::Now.ToString('o')
if (-not $Preflight) {
  if ($state.PSObject.Properties['buildAttempt']) { throw 'Never reuse consumed build attempt' }
  $state | Add-Member -NotePropertyName buildAttempt -NotePropertyValue @{startedAt=$started;state='started';log=$log}
  $state | ConvertTo-Json -Depth 30 | Set-Content -LiteralPath $statePath -Encoding utf8
}
$buildExitCode=0
try {
  & .\scripts\build-buy-device-review.ps1 -CandidateId UAW-CURSOR-BUY-R6633-20260922 -BuildName 1.0.0-r66.33 -BuildNumber 2026092202 -SourceFingerprint $state.source.manifestSha256 -ArtifactDirectory $artifactRelative -BuildMode debug -MachineStatePath $statePath -RuntimeProfile CursorUiReview -EvidenceArchiveRoot 'C:\GUARANTEED OUTCOME\MOOLSOCIAL-ARCHIVE-DIRTY-WORKTREES-20260904' -PreflightOnly:$Preflight *> $log
  if (-not $?) { throw 'Candidate wrapper failed' }
} catch {
  $buildExitCode=1
  $_ | Out-String | Add-Content -LiteralPath $log
} finally {
  if (-not $Preflight) {
    $state=Get-Content -LiteralPath $statePath -Raw | ConvertFrom-Json
    $state.buildAuthorization='consumed'
    $state.machineState=if ($buildExitCode -eq 0) {'built_device_verification_pending'} else {'build_failed'}
    $state.buildAttempt.state=if ($buildExitCode -eq 0) {'built'} else {'failed'}
    $state.buildAttempt | Add-Member -NotePropertyName finishedAt -NotePropertyValue ([DateTimeOffset]::Now.ToString('o'))
    $state | ConvertTo-Json -Depth 30 | Set-Content -LiteralPath $statePath -Encoding utf8
  }
}
@{attempt=$Attempt;preflight=[bool]$Preflight;startedAt=$started;finishedAt=[DateTimeOffset]::Now.ToString('o');exitCode=$buildExitCode;log=$log} | ConvertTo-Json | Set-Content -LiteralPath $result
Get-Content -LiteralPath $log -Tail 12
exit $buildExitCode
