param([Parameter(Mandatory)][ValidateSet('legacy','buy1','buy2','buy3','analysis')][string]$Check)
$ErrorActionPreference = 'Stop'
$taskRoot = 'C:\GUARANTEED OUTCOME\MOOLSOCIAL-WORKTREE-CURSOR-buy-ready-20260921'
$artifactRoot = Join-Path $taskRoot 'apps/mobile/build/review-candidates/cursor-buy-r6633-20260922'
$null = New-Item -ItemType Directory -Path $artifactRoot -Force
$log = Join-Path $artifactRoot ($Check + '.log')
$result = Join-Path $artifactRoot ($Check + '.result.json')
if ((Test-Path -LiteralPath $log) -or (Test-Path -LiteralPath $result)) { throw 'Preserve existing attempt; use a new log name.' }
$started = [DateTimeOffset]::Now.ToString('o')
$taskHead = (& git -C $taskRoot rev-parse HEAD).Trim()
if ($LASTEXITCODE -ne 0) { throw 'Cannot read candidate HEAD.' }
Set-Location (Join-Path $taskRoot 'apps/mobile')
$flutter = 'C:\Users\jisal\develop\flutter\bin\flutter.bat'
if ($Check -eq 'legacy') {
  $targets = @('test/ui_v2/buy/buy_v2_product_decision_glance_test.dart','test/ui_v2/buy/buy_v2_product_offer_decision_test.dart','test/ui_v2/buy/buy_v2_wholesale_trade_decision_test.dart','test/ui_v2/buy/buy_v2_shop_pharmacy_seller_continuity_test.dart')
  & $flutter test --no-pub --reporter expanded @targets *> $log
} elseif ($Check -in @('buy1','buy2','buy3')) {
  & $flutter test --no-pub --reporter expanded test/ui_v2/buy *> $log
} else {
  & 'C:\Users\jisal\develop\flutter\bin\dart.bat' analyze lib/features/buy lib/ui_v2/buy test/ui_v2/buy *> $log
}
$code = $LASTEXITCODE
[ordered]@{check=$Check; head=$taskHead; started=$started; ended=[DateTimeOffset]::Now.ToString('o'); exitCode=$code; log=$log} | ConvertTo-Json | Set-Content -LiteralPath $result -Encoding utf8
Get-Content -LiteralPath $log -Tail 8
Write-Output "RESULT check=$Check exitCode=$code log=$log"
exit $code
