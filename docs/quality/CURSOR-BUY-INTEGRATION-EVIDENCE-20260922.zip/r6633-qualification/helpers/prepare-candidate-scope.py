from pathlib import Path
import json, hashlib
r=Path(r'C:\GUARANTEED OUTCOME\MOOLSOCIAL-WORKTREE-CURSOR-buy-ready-20260921')
old=json.loads((r/'config/mvp-scope-gate-state.json').read_text(encoding='utf-8-sig'))
evidence='docs/quality/CURSOR-BUY-INTEGRATION-HANDOFF-20260922.md'
ticket='UAW-CURSOR-BUY-R6633-20260922'
outcome='Reconciled Cursor Buy changes are present in one fresh isolated Redmi review APK and their device outcomes are recorded.'
exclusions=['No backend or Google API implementation','No Store worktree edits or integration','No production release, Play upload, external messages, data clearing or downgrade']
deps=['Founder: if git is safe then move ahead with redme apk','Standing narrow authority to repair qualification blockers','Store and live Google dependencies explicitly deferred']
coverage=['Exact source manifest and clean remote Git readback','Two complete Buy regression passes on frozen inputs','Unchanged protected, UI-lock, backend/egress and plugin checks','Unique debug CursorUiReview candidate and installed checksum','Focused physical Redmi replay of 22 reconciled outcomes']
scope=['Preserve all reconciled commits and local work','Repair only qualification regressions','Build through existing guarded wrapper','Install isolated package on TG8HCYTGGQT885OF preserving data','Record device results and park Git clean']
state={k:old[k] for k in ['schemaVersion','contractId','policy','deliveryDisciplineLock']}
state['preTicketSelectionCheckpoint']={k:old['preTicketSelectionCheckpoint'][k] for k in ['checkpointId','path','sha256']}
state['preTicketSelectionCheckpoint'].update(state='selected_ticket_assessed',currentTicketId=ticket,selectedTicketAssessment={
 'ticketId':ticket,'customerOutcome':outcome,'manifestPath':evidence,
 'manifestSha256':hashlib.sha256((r/evidence).read_text(encoding='utf-8-sig').encode()).hexdigest().upper(),
 'reuseInventoryComplete':True,'duplicateSearchComplete':True,
 'implementationDisposition':['reuse','test_only_acceptance','new_necessary_work'],
 'sharedImplementationOwners':['scripts/build-buy-device-review.ps1','scripts/check-apk-regression-gate-state.ps1','apps/mobile/lib/ui_v2/buy/buy_v2_screen.dart'],
 'newScreens':[],'newRoutes':[],'newBackendOwners':[],
 'necessityProof':'Reuse the existing candidate wrapper, contracts and screens; fix failed qualification checks without weakening assertions or adding another build path.',
 'robustnessCoverage':coverage,'adjustments':scope,'explicitExclusions':exclusions,'dependenciesAndApprovals':deps,
 'timelineImpactDays':0,'within60To75DayLock':True,'evidencePath':evidence})
state.update(state='ticket_disclosed_and_authorized',checkpoint={'successorRegistered':True},ticket={
 'id':ticket,'customerOutcome':outcome,'classification':'mvp_required',
 'classificationReason':'The installed r66.32 predates the approved Buy fixes; a fresh isolated review APK is required to verify them.',
 'minimumCompleteScope':scope,'explicitExclusions':exclusions,'dependenciesAndApprovals':deps,'testAndEvidencePlan':coverage},
 founderDisclosure={'state':'presented_before_execution','evidence':evidence},
 authorization={'state':'existing_ticket_authority_confirmed','evidence':evidence,'beyondMvpExplicitlyAuthorized':False},
 execution={'referenceWriteAuthorized':False,'runtimeWriteAuthorized':True,'testOrGateWriteAuthorized':True,'backendWriteAuthorized':False,'buildAuthorized':True,'deviceInstallAuthorized':True,'externalServiceWriteAuthorized':False})
p=r/'apps/mobile/build/review-candidates/cursor-buy-r6633-20260922/scope-state.json'
p.write_bytes((json.dumps(state,indent=2)+'\n').encode())
print(p)
