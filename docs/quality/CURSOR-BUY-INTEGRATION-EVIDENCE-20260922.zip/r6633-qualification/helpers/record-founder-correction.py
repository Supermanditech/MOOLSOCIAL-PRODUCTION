from pathlib import Path
import json, shutil
r=Path(r'C:\GUARANTEED OUTCOME\MOOLSOCIAL-WORKTREE-CURSOR-buy-ready-20260921')
a=r/'apps/mobile/build/review-candidates/cursor-buy-r6633-20260922'
for name in ['device-replay.json','DEVICE-REPORT.md']:
 p=a/name; backup=a/(p.stem+'-initial'+p.suffix)
 assert not backup.exists(); shutil.copy2(p,backup)
p=a/'device-replay.json';d=json.loads(p.read_text())
finding={'id':'R6633-D03','parent':'RB013 / founder Recently viewed compact-popup ticket','type':'confirmed_founder_reopened_defect','status':'open_not_fully_implemented','title':'Recently viewed cards retain empty Add row and excessive sheet spacing','actual':'Add is narrower, but remains a separate trailing row under metadata. Large image/card and separate Clear row keep sheet sparse. Founder rejects this as fulfillment of compact premium layout.','expected':'Compact professional Recent sheet and cards; group thumbnail, relevant metadata and Add without an empty full-width action lane; compact header/Clear; preserve readable long text, accessible hit areas, safe insets, correct SKU/Add/navigation.','evidence':['redmi/042-recently-viewed.png','redmi/042-recently-viewed.xml'],'source':'apps/mobile/lib/ui_v2/buy/buy_v2_catalogue.dart:_RecentlyViewedProductInfoRow; metadata Column ends with Align(centerRight, add).','gitDisposition':'Partial change is in a78b1b38/f4d2e116 ancestry, included in frozen HEAD1650a1dd and checksum-verified installed r66.33. No missing commit or lost local work.','next':'Implement full compact card/sheet layout in next authorized frontend change; local geometry/long-text/keyboard tests plus founder screenshot and next Redmi replay. Do not count narrower button alone as acceptance.'}
d['findings'].append(finding)
row=next(t for t in d['tickets'] if t['number']==6)
row['deviceStatus']='child_open_founder_rejected_compactness'
row['result']='Pickup banners removed, but Recently viewed spacing requirement is incomplete. Narrower Add still consumes a separate row; R6633-D03 reopened after founder review. Earlier observed_frontend_pass was too broad and is superseded.'
d['founderCorrection']='Founder explicitly rejected Recently viewed empty Add lane and lack of compact premium layout. Registered D03; no app code changed during frozen APK parking.'
p.write_text(json.dumps(d,indent=2)+'\n')
report=a/'DEVICE-REPORT.md';txt=report.read_text(encoding='utf-8')
txt=txt.replace('Two confirmed child defects and one investigation registered','Three confirmed child defects and one investigation registered')
lines=txt.splitlines()
for i,line in enumerate(lines):
 if line.startswith('| 6 |'): lines[i]='| 6 | RB013 | child_open_founder_rejected_compactness: pickup banners removed, but Recently viewed still wastes a separate Add lane. R6633-D03 supersedes the earlier partial pass. | redmi/042-recently-viewed.png |'
lines.extend(['','## Founder correction: R6633-D03 — Recently viewed compactness remains incomplete','',finding['actual'],finding['expected'],finding['gitDisposition'],'','The initial replay assessment accepted button width too narrowly. Founder rejection supersedes that assessment. The initial report is retained as DEVICE-REPORT-initial.md for audit; this corrected report is authoritative. No implementation or APK rebuild is claimed.',''])
report.write_text('\n'.join(lines),encoding='utf-8')
p=a/'apk-state.json';s=json.loads(p.read_text());s['postBuildGates']['buyDefectReplay']='focused_complete_three_open_children_one_investigation_provider_cases_deferred';p.write_text(json.dumps(s,indent=2)+'\n')
print('R6633-D03 reopened; initial report retained; corrected disposition saved')
