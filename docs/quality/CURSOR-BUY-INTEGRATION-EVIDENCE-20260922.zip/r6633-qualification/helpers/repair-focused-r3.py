from pathlib import Path
r=Path(r'C:\GUARANTEED OUTCOME\MOOLSOCIAL-WORKTREE-CURSOR-buy-ready-20260921\apps\mobile\test\ui_v2\buy')
p=r/'buy_v2_screen_test.dart';t=p.read_text(encoding='utf-8-sig')
t=t.replace("import 'buy_v2_qualified_provider_fixture.dart';", "import 'buy_v2_qualified_provider_fixture.dart';\nimport 'package:moolsocial/ui_v2/buy/buy_v2_address_sheet_motion.dart';",1)
t=t.replace('tester.view.physicalSize.height / tester.view.devicePixelRatio - tester.view.viewPadding.bottom / tester.view.devicePixelRatio', "tester.view.physicalSize.height / tester.view.devicePixelRatio - BuyV2AddressSheetMotion.resolveBottomSafeInset(tester.element(find.byKey(const ValueKey('buy-category-sheet-surface'))))",1)
start=t.index("  testWidgets('add confirmation is owned");end=t.index("  testWidgets('R66 fixed Cart",start)
a=t[start:end]
a=a.replace("find.byKey(const ValueKey('buy-mini-cart-added-icon'))", "find.descendant(of: find.byKey(const ValueKey('buy-cart-navigation-button')), matching: find.byIcon(Icons.shopping_cart_outlined))")
a=a.replace("find.byKey(const ValueKey('buy-mini-cart-icon'))", "find.descendant(of: miniCart, matching: find.byIcon(Icons.shopping_cart_outlined))")
t=t[:start]+a+t[end:]
start=t.index("'RV6 D011 $mode content preserves unique facts");end=t.index("  testWidgets('all six recovery states",start)
a=t[start:end]
a=a.replace("            final content = find.byKey(", "            final hero = find.byKey(ValueKey('buy-product-purchase-hero-${product.id}'));\n            expect(find.descendant(of: hero, matching: find.textContaining(product.pack)), findsWidgets);\n            final content = find.byKey(",1)
a=a.replace("            expect(find.text(product.pack), findsWidgets);\n",'')
t=t[:start]+a+t[end:];p.write_bytes(t.encode('utf-8'))
p=r/'buy_v2_partner_catalogue_test.dart';t=p.read_text(encoding='utf-8-sig')
start=t.index("'R5 paged published Offers journey");end=t.index("'R5 paged catalogue user actions",start)
a=t[start:end].replace("find.byKey(const ValueKey('buy-public-store-name'))", "find.byKey(const ValueKey('buy-store-toolbar-name'))")
a=a.replace('          storeAction,\n          -180,', '          storeAction,\n          180,',1)
a=a.replace('        await tester.ensureVisible(storeAction);', '        await Scrollable.ensureVisible(tester.element(storeAction), alignment: .4);',1)
t=t[:start]+a+t[end:];p.write_bytes(t.encode('utf-8'))
print('Adjusted scoped assertions for safe inset, fixed Cart badge, inline pack and Store toolbar')
