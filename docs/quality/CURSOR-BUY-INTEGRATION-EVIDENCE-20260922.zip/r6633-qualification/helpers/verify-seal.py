from pathlib import Path
import hashlib, json, subprocess, sys
r=Path(r'C:\GUARANTEED OUTCOME\MOOLSOCIAL-WORKTREE-CURSOR-buy-ready-20260921')
a=r/'apps/mobile/build/review-candidates/cursor-buy-r6633-20260922'
name=sys.argv[1];assert name.replace('-','').isalnum()
target=a/(name+'.json');assert not target.exists()
seal=json.loads((a/'source-seal.json').read_text())
manifest=r/seal['source']['manifestPath']
assert hashlib.sha256(manifest.read_bytes()).hexdigest().upper()==seal['source']['manifestSha256']
rows=manifest.read_text().splitlines();assert len(rows)==seal['source']['fileCount']
mismatches=[]
for row in rows:
 expected,path=row.split('  ',1);p=r/path
 if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest().upper()!=expected: mismatches.append(path)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()
status=subprocess.check_output(['git','status','--porcelain'],cwd=r,text=True)
result={'fileCount':len(rows),'mismatches':mismatches,'sealedSourceHead':seal['head'],'currentHead':head,'gitClean':not status,'state':'passed' if not mismatches else 'failed'}
target.write_bytes((json.dumps(result,indent=2)+'\n').encode())
print(json.dumps(result));assert not mismatches
