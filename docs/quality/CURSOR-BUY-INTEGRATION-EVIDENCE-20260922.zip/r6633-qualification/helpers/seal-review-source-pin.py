from pathlib import Path
import subprocess, hashlib
r=Path(r'C:\GUARANTEED OUTCOME\MOOLSOCIAL-WORKTREE-CURSOR-buy-ready-20260921')
source='02369e96a293e4588cca06efad17a02bf53470a8'
previous='c1197ec99beaac064ee1cc635bff1d1aabe9ece6'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==source
delta=subprocess.check_output(['git','diff','--name-only','3959b3c23ba09f66397b74313b8ddfb90c761442',source,'--','apps','backend','contracts','packages','package.json','package-lock.json','pubspec.yaml','pubspec.lock'],cwd=r,text=True).splitlines()
assert len(delta)==21, len(delta)
assert [p for p in delta if not p.startswith('apps/mobile/test/ui_v2/buy/')]==['apps/mobile/lib/ui_v2/buy/buy_v2_screen.dart']
for name in ['check-buy-protected-baseline.ps1','check-buy-backend-contract-boundary.ps1','check-buy-data-egress-boundary.ps1']:
 p=r/'scripts'/name;t=p.read_text(encoding='utf-8-sig');assert previous in t;t=t.replace(previous,source)
 if name=='check-buy-protected-baseline.ps1':
  start=t.index('    $expectedDelta = @(',t.index('function Test-CursorStorefrontPickupReviewSource'))
  end=t.index('    $delta = @(',start)
  t=t[:start]+"    $expectedDelta = @(\n"+',\n'.join("      '"+p+"'" for p in sorted(delta))+"\n    )\n"+t[end:]
 if name=='check-buy-backend-contract-boundary.ps1':
  sha=hashlib.sha256((r/'apps/mobile/lib/ui_v2/buy/buy_v2_screen.dart').read_text(encoding='utf-8-sig').encode()).hexdigest().upper()
  old='DB66EF9AB33AAD3E7B75D2CEA8881177E477FF726DAF2281522BE6BDD8B75B2A'
  assert t.count(old)==1;t=t.replace(old,sha)
 p.write_bytes(t.encode())
print('Pinned source',source,'with',len(delta),'exact application/test delta owners')
