from pathlib import Path
import json
r=Path(r'C:\GUARANTEED OUTCOME\MOOLSOCIAL-WORKTREE-CURSOR-buy-ready-20260921')
names=['category_sheet_style_motion_test','order_resolution_test','prescription_match_continuity_test','product_content_test','product_compact_action_test','product_actions_test','product_variant_selection_test','shopping_settings_test','wholesale_supplier_continuity_test','qualified_provider_fixture']
owners=['apps/mobile/test/ui_v2/buy/buy_v2_'+n+'.dart' for n in names]
p=r/'config/codex-subagent-coordination-policy.json'
t=p.read_text(encoding='utf-8-sig'); obj=json.loads(t)
root=next(c for c in obj['activeClaims'] if c['task']=='/root')
assert all(o not in root['owners'] for o in owners)
# Transfer only these test owners from inherited inactive Cursor claims.
for o in owners:
    line='        '+json.dumps(o)+',\n'
    assert t.count(line)<=1
    t=t.replace(line,'')
anchor='        "apps/mobile/.flutter-plugins-dependencies"\n'
assert t.count(anchor)==1
t=t.replace(anchor,anchor.rstrip('\n')+',\n'+',\n'.join('        '+json.dumps(o) for o in owners)+'\n')
p.write_bytes(t.encode('utf-8'))
p=r/'scripts/check-codex-subagent-coordination-policy.ps1';t=p.read_text(encoding='utf-8-sig')
anchor="$cursorReviewQualificationOwners = @(\n"
assert t.count(anchor)==1
t=t.replace(anchor,anchor+'  # Exact Buy regression owners needed to qualify the approved layouts.\n'+''.join("  '"+o+"',\n" for o in owners))
p.write_bytes(t.encode('utf-8'))
print('Admitted',len(owners),'exact test-only owners; no enforcement changed.')
