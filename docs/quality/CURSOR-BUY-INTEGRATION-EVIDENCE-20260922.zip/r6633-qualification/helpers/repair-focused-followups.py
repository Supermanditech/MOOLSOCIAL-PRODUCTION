from pathlib import Path
r=Path(r'C:\GUARANTEED OUTCOME\MOOLSOCIAL-WORKTREE-CURSOR-buy-ready-20260921\apps\mobile\test\ui_v2\buy')
p=r/'buy_v2_product_actions_test.dart';t=p.read_text(encoding='utf-8-sig')
old='      products: BuyV2Catalogue.allProducts,'
assert t.count(old)==1
t=t.replace(old,'''      // This review test's background basket has an explicit simulated
      // listing identity; a missing Store id must never receive eligibility.
      products: BuyV2Catalogue.allProducts.map((p) => p.id == 'w-notebook'
          ? p.copyWith(storeId: 'simulated-review-notebook-store', offerClass: BuyV2OfferClass.wholesale)
          : p).toList(),''')
p.write_bytes(t.encode('utf-8'))
p=r/'buy_v2_product_content_test.dart';t=p.read_text(encoding='utf-8-sig')
s=t.index('        await tester.scrollUntilVisible(\n          compliance,');e=t.index("        expect(find.text('Buy now')",s)
t=t[:s]+'''        expect(product.compliance, isNull);
        expect(product.mrp, isNull);
        expect(compliance, findsNothing);
        expect(find.descendant(of: hero, matching: find.textContaining(product.pack)), findsWidgets);
'''+t[e:];p.write_bytes(t.encode('utf-8'))
p=r/'buy_v2_product_variant_selection_test.dart';t=p.read_text(encoding='utf-8-sig')
s=t.index("        expect(\n          find.byKey(const ValueKey('buy-automatic-fulfilment-s-milk-500ml')),");e=t.index('        await tester.tap(add);',s)
t=t[:s]+'''        final delivery = find.byKey(const ValueKey('buy-automatic-fulfilment-s-milk-500ml'));
        final productScroll = find.descendant(
          of: find.byKey(const PageStorageKey('buy-product-s-milk-500ml')),
          matching: find.byType(Scrollable)).first;
        await tester.scrollUntilVisible(delivery, 120, scrollable: productScroll);
        expect(delivery, findsOneWidget);
        expect(find.descendant(of: delivery, matching: find.textContaining('Standard/courier delivery')), findsWidgets);
        expect(find.text('Quick local choice'), findsNothing);
        await tester.scrollUntilVisible(add, -120, scrollable: productScroll);
        await Scrollable.ensureVisible(tester.element(add), alignment: .4);
        await tester.pumpAndSettle();
        expect(add.hitTestable(), findsOneWidget);
'''+t[e:];p.write_bytes(t.encode('utf-8'))
for name in ['buy_v2_screen_test.dart','buy_v2_scoped_cart_checkout_dock_continuity_test.dart']:
 p=r/name; proposal=Path(__file__).parent/'proposed-r2'/name
 p.write_bytes(proposal.read_bytes())
print('Applied follow-up provider identity, product scrolling and screen test revisions')
