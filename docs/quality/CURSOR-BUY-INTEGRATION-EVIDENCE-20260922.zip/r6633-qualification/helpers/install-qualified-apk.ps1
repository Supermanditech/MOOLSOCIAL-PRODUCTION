$ErrorActionPreference='Stop'
$env:DEBUG=''
$taskRoot='C:\GUARANTEED OUTCOME\MOOLSOCIAL-WORKTREE-CURSOR-buy-ready-20260921'
$artifactRoot=Join-Path $taskRoot 'apps/mobile/build/review-candidates/cursor-buy-r6633-20260922'
$apk=Join-Path $artifactRoot 'uaw-cursor-buy-r6633-20260922-device-review-debug.apk'
$state=Get-Content -LiteralPath (Join-Path $artifactRoot 'apk-state.json') -Raw | ConvertFrom-Json
if ($state.buildAuthorization -cne 'consumed' -or $state.machineState -cne 'built_device_verification_pending') { throw 'No qualified built candidate to install' }
$analyzer='C:\Users\jisal\AppData\Local\Android\Sdk\cmdline-tools\latest\bin\apkanalyzer.bat'
$signer='C:\Users\jisal\AppData\Local\Android\Sdk\build-tools\36.0.0\apksigner.bat'
$adb='C:\Users\jisal\AppData\Local\Android\Sdk\platform-tools\adb.exe'
$serial='TG8HCYTGGQT885OF'
$package='com.moolsocial.app.cursorreview'
$receipt=Join-Path $artifactRoot 'installed-identity.json'
$installLog=Join-Path $artifactRoot 'adb-install.log'
if ((Test-Path $receipt) -or (Test-Path $installLog)) { throw 'Preserve earlier installation receipt' }
$actualPackage=(& $analyzer manifest application-id $apk).Trim()
if ($LASTEXITCODE -ne 0 -or $actualPackage -cne $package) { throw 'Wrong APK package' }
$version=(& $analyzer manifest version-name $apk).Trim()
if ($LASTEXITCODE -ne 0 -or $version -cne '1.0.0-r66.33-cursorreview') { throw 'Wrong APK version' }
$code=(& $analyzer manifest version-code $apk).Trim()
if ($LASTEXITCODE -ne 0 -or $code -cne '2026092202') { throw 'Wrong APK code' }
& $signer verify --print-certs $apk *> (Join-Path $artifactRoot 'apk-signer.log')
if ($LASTEXITCODE -ne 0) { throw 'APK signature verification failed' }
$certificate=Get-Content -LiteralPath (Join-Path $artifactRoot 'apk-signer.log') -Raw
if ($certificate -notmatch 'SHA-256 digest: cbdfc5969ad51ed570afb1cf2fe60377e559d43f59d59e2ab66ccaf78ea9ac25') { throw 'APK signer differs from retained predecessor' }
$deviceState=(& $adb -s $serial get-state).Trim()
if ($LASTEXITCODE -ne 0 -or $deviceState -cne 'device') { throw 'Redmi is unavailable' }
$before=(& $adb -s $serial shell dumpsys package $package) -join "`n"
if ($LASTEXITCODE -ne 0 -or $before -notmatch 'versionCode=2026092201\b') { throw 'Installed predecessor changed; reconcile before installing' }
$apkSha=(Get-FileHash -LiteralPath $apk -Algorithm SHA256).Hash
& $adb -s $serial install -r $apk *> $installLog
if ($LASTEXITCODE -ne 0 -or (Get-Content -LiteralPath $installLog -Raw) -notmatch 'Success') { throw 'Preserved-data update failed; do not uninstall or clear data' }
$paths=@(& $adb -s $serial shell pm path $package)
if ($LASTEXITCODE -ne 0 -or $paths.Count -ne 1 -or $paths[0] -cnotmatch '^package:(/data/app/[A-Za-z0-9_~./=+-]+/base\.apk)$') { throw 'Cannot resolve the installed base APK' }
$installedPath=$Matches[1]
$deviceSha=((& $adb -s $serial shell sha256sum $installedPath) -split '\s+')[0].ToUpperInvariant()
if ($LASTEXITCODE -ne 0 -or $deviceSha -cne $apkSha) { throw 'Installed checksum mismatch' }
$pulled=Join-Path $artifactRoot 'installed-r66.33-base.apk'
if (Test-Path $pulled) { throw 'Preserve prior installed binary' }
& $adb -s $serial pull $installedPath $pulled *> (Join-Path $artifactRoot 'adb-pull-installed.log')
if ($LASTEXITCODE -ne 0 -or (Get-FileHash -LiteralPath $pulled -Algorithm SHA256).Hash -cne $apkSha) { throw 'Pulled installed bytes mismatch' }
$after=(& $adb -s $serial shell dumpsys package $package) -join "`n"
if ($LASTEXITCODE -ne 0 -or $after -notmatch 'versionCode=2026092202\b' -or $after -notmatch 'versionName=1.0.0-r66.33-cursorreview\b') { throw 'Installed version mismatch' }
@{candidate='UAW-CURSOR-BUY-R6633-20260922';device=$serial;package=$package;version=$version;versionCode=$code;apkPath=$apk;apkSha256=$apkSha;installedSha256=$deviceSha;pulledApkPath=$pulled;signerSha256='CBDFC5969AD51ED570AFB1CF2FE60377E559D43F59D59E2AB66CCAF78EA9AC25';installMode='adb install -r; no data clear or uninstall';verifiedAt=[DateTimeOffset]::Now.ToString('o');state='installed_checksum_verified_device_replay_pending'} | ConvertTo-Json | Set-Content -LiteralPath $receipt -Encoding utf8
Get-Content -LiteralPath $receipt
