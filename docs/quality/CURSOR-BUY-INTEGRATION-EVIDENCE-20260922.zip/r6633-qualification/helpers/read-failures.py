from pathlib import Path
import re, json, sys
p=Path(r'C:\GUARANTEED OUTCOME\MOOLSOCIAL-WORKTREE-CURSOR-buy-ready-20260921\apps\mobile\build\review-candidates\cursor-buy-r6633-20260922\buy1.log')
if len(sys.argv)>1: p=p.with_name(sys.argv[1]+'.log')
t=p.read_text(encoding='utf-8-sig')
rows=[]
for block in re.split(r'.*EXCEPTION CAUGHT BY FLUTTER.*\n',t)[1:]:
    frames=re.findall(r'/apps/mobile/(test/[^\s)]+)',block)
    if not frames: continue
    # Bound each report at the Flutter exception terminator.
    lines=block.splitlines()
    end=next((i for i,l in enumerate(lines) if l.startswith('═')),len(lines))
    report='\n'.join(lines[:end])
    frames=re.findall(r'/apps/mobile/(test/[^\s)]+)',report)
    description=re.search(r'The test description was:\s*\n\s*(.+)',report)
    before=report.split('When the exception')[0]
    rows.append({'frames':list(dict.fromkeys(frames)), 'description':description[1] if description else '', 'error':before[:1100]})
unique={json.dumps(x,sort_keys=True):x for x in rows}
out=p.with_name(p.stem+'-failures.json')
out.write_text(json.dumps(list(unique.values()),indent=2)+'\n',encoding='utf-8')
group={}
for row in unique.values():
    key=(row['frames'][0] if row['frames'] else '?',row['error'])
    group.setdefault(key,[]).append(row['description'])
for (frame,error),names in group.items():
    print(frame, 'cases',len(names),names[0]);print(error[:450])
print('FAILED TESTS',sum('[E]' in l for l in t.splitlines()),'LAST',t.splitlines()[-1])
