param([Parameter(Mandatory)][string]$RunId,[string]$Names,[Parameter(Mandatory)][string[]]$Files)
$ErrorActionPreference = 'Stop'
$root = 'C:\GUARANTEED OUTCOME\MOOLSOCIAL-WORKTREE-CURSOR-buy-ready-20260921'
Set-Location "$root\apps\mobile"
$log = "build/review-candidates/cursor-buy-r6633-20260922/$RunId.log"
$result = "build/review-candidates/cursor-buy-r6633-20260922/$RunId.result.json"
if ((Test-Path $log) -or (Test-Path $result)) { throw 'Preserve prior run evidence' }
$started = (Get-Date).ToUniversalTime().ToString('o')
$head = & git rev-parse HEAD
$testArgs = @('test','--no-pub','--reporter','expanded') + @($Files | ForEach-Object {"test/ui_v2/buy/$_"})
if ($Names) { $testArgs += @('--name',$Names) }
& 'C:\Users\jisal\develop\flutter\bin\flutter.bat' @testArgs *> $log
$code = $LASTEXITCODE
@{runId=$RunId;sourceCommit=$head;startedAt=$started;finishedAt=(Get-Date).ToUniversalTime().ToString('o');exitCode=$code;arguments=$testArgs;log=$log} | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $result
Get-Content -LiteralPath $log -Tail 10
exit $code
