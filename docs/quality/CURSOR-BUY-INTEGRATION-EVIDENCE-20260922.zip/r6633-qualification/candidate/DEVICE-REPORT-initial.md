# r66.33 Redmi qualification and focused replay

Built and installed `1.0.0-r66.33-cursorreview` / `2026092202` on Redmi `TG8HCYTGGQT885OF`.
APK / installed / pulled SHA-256: `968933D16519BBE6AC757C10ACA39368F87A7605CFAB0CF1F6C4E28DD73E1FC7`.

Build source: `1650a1ddb3bf3672530c8d345d0a5c3e9f475aba`; source manifest: `AFCDD9532CEB895C144414C0ED7066F78813A825A27E2616CC6BB5B357ADA799`, 3,236 unchanged inputs. All 22 reconciled post-r66.32 outcomes are included. Eligibility ticket 11 is included, frontend only.

Two full Buy qualification runs each passed 2,527 tests, 27 skipped, zero failures. Analyzer: no errors/warnings, eight existing informational notices. Build preflight and APK plugin/signature/package/version checks passed. This is isolated CursorUiReview debug, not production/backend acceptance.

## Open observations from this device replay

### R6633-D01 — Combined historical active-order estimate still says Delivered

Status: open_registered_not_implemented. Parent: RB026.
Last recorded estimate: Delivery today by 8:00 pm · Delivered in 30 min.
Next: Normalize each combined estimate component while preserving true delivered history; regression for multi-line historical restoration.
Evidence: redmi/027-orders-lower.png, redmi/027-orders-lower.xml

### R6633-D02 — Nested Recently viewed product omits aggregate Cart access

Status: open_registered_not_implemented. Parent: CURSOR-BUY-CART-POSITION-ALL-SURFACES-20260922.
Organized nested product fills screen without Cart or bottom rail although aggregate basket contains six packs; root Shop product has All carts.
Next: Inspect nested product overlay Cart scope and fixed safe-area control without altering parent navigation.
Evidence: redmi/042-recently-viewed.png, redmi/043-product-actions.png, redmi/043-product-actions.xml, redmi/005-product-scrolled.png

### R6633-O01 — Displayed Cart amount rises by INR 300 after update/relaunch

Status: open_needs_cause_verification. Parent: retained-data-upgrade.
Before: 6 items INR 14,692; after: same six packs, three lines totaling INR 14,992 (4840+6192+3960). No quantity edit or coupon action performed.
Next: Reproduce coupon selection then relaunch on same build and inspect persisted benefit contract before assigning runtime cause. Not proven data loss or price change.
Evidence: redmi/000-preinstall-r6632-state.png, redmi/018-retained-cart.png, redmi/019-retained-cart-rest.png, redmi/024-payment.png

## Per-ticket disposition

Device smoke is bounded; host pass does not imply every device journey was repeated or closed.

| # | Ticket | Device result | Evidence |
|---|---|---|---|
| 1 | RB006 | observed_frontend_pass: Normalized current Store names visible in Cart continuation and final review; historical order names are retained history. | redmi/018-retained-cart.png, redmi/025-review-no-submit.png, redmi/047-cart-restore.png |
| 2 | RB007 | observed_frontend_pass: Shop and Wholesale Store search expand, scope results to current Store, and retain query after Finish. Stable-input replay verifies rice; first rapid ADB entry lost initial r during focus transition, retained as tool timing observation. | redmi/009-store-search-keyboard.png, redmi/010-search-finish.png, redmi/034-wholesale-store-search-stable.png |
| 3 | RB008 | partial_provider_deferred: Compact Store address and Maps action present; authentic Store pin and external Maps destination not accepted. | redmi/014-store-information.png, redmi/025-review-no-submit.png |
| 4 | RB011 | partial_provider_deferred: Pickup selection survives sign-in route Back. Review Store data resolves no collectible line: zero products, Check total, disabled Continue. Live pickup completion remains unqualified. | redmi/021-pickup-selection.png, redmi/022-pickup-signin.png, redmi/023-pickup-back.png |
| 5 | RB012 | observed_unavailable_recovery_provider_deferred: Unconfirmed delivery prevents order placement and offers change-address/edit-basket recovery. No live payment or order submitted. | redmi/025-review-no-submit.png |
| 6 | RB013 | observed_frontend_pass: Store information and Wholesale supplier grid have no Order & Collect banner. Recently viewed uses compact trailing Add. Manual-area tick superseded by current-location frontend. | redmi/014-store-information.png, redmi/032-wholesale-store.png, redmi/042-recently-viewed.png |
| 7 | RB018 | partial_device_replay: Payment summary and Wholesale benefit data reached. No new on-device offer selection/discount replay; full local regression evidence retained. | redmi/024-payment.png, redmi/031-wholesale-product.png |
| 8 | RB022 | not_device_replayed_host_passed: Saved Work address restored; recipient editing/keyboard accessibility specifically not replayed in this bounded smoke check. | redmi/049-work-restored.png |
| 9 | RB026 | child_open: Single-product active orders show Delivery in; mixed historical MS-NEW-03 retains Delivered in 30 min inside combined estimate. R6633-D01 remains open. | redmi/026-orders.png, redmi/027-orders-lower.png |
| 10 | RB029 | partial_provider_deferred: Named review Store/SKU/pack distinctions and honest illustration labels observed. Authentic catalogue/photos and real variant provider remain deferred. | redmi/007-visit-store.png, redmi/009-store-search-keyboard.png, redmi/031-wholesale-product.png, redmi/032-wholesale-store.png |
| 11 | ELIGIBILITY-11 | host_contract_pass_device_unavailable_observed: Explicit eligibility contract included since a78b1b38. Full host suites cover missing/expired/channel/offer distinctions. Device blocks unconfirmed delivery. Real Store/fleet readiness and booked slots not accepted. | redmi/017-wholesale.png, redmi/025-review-no-submit.png, redmi/030-offers.png |
| 12 | CURSOR-BUY-QUANTITY-WIDTH-20260922 | observed_frontend_pass: Product Add is bounded; Cart and Wholesale steppers occupy compact trailing space. No quantities changed during this replay. | redmi/005-product-scrolled.png, redmi/018-retained-cart.png, redmi/019-retained-cart-rest.png, redmi/031-wholesale-product.png, redmi/032-wholesale-store.png |
| 13 | CURSOR-BUY-DELIVERY-PROVENANCE-20260922 | observed_frontend_pass: Historical 12-active-order cache does not expose bottom Delivery tab; six-pack Cart remains accessible. | redmi/003-r6633-startup.png, redmi/026-orders.png, redmi/030-offers.png, redmi/050-final-home.png |
| 14 | CURSOR-BUY-CART-SCROLL-STABILITY-20260922 | partial_child_open: Root product Cart stays at same bounds after scroll. Nested Recently viewed product has no aggregate Cart for six Wholesale packs; R6633-D02 open. | redmi/004-shop-product.png, redmi/005-product-scrolled.png, redmi/043-product-actions.png |
| 15 | CURSOR-BUY-COMPARE-SHEET-REGRESSION-20260922 | observed_unavailable_state_provider_deferred: Compare opens honest unavailable-supplier response with Refresh above Android navigation. Populated comparison remains host-tested only. | redmi/044-compare.png |
| 16 | CURSOR-BUY-SEARCH-DELIVERY-FLEET-20260922 | observed_inactive_pass_active_host_only: Search has no fleet UI. Active live-delivery device case not manufactured; covered by host tests only. | redmi/009-store-search-keyboard.png, redmi/034-wholesale-store-search-stable.png, redmi/038-buy-search.png |
| 17 | CURSOR-BUY-ORDER-INVOICE-ACTIONS-20260922 | not_device_replayed_host_passed: Orders and Offers reached, but specific Offers Manage order/View invoice context was not reproduced. Do not close device obligation from these screenshots. | redmi/026-orders.png, redmi/030-offers.png |
| 18 | CURSOR-BUY-MVP-MEDICINE-PROMO-20260922 | partial_device_replay_host_passed: Orders continuation reaches relevant product grid. Screenshots are sampled, not proof of every scroll position; explicit medicine-promo absence assertion passed in both host runs. | redmi/026-orders.png, redmi/028-orders-bottom.png, redmi/029-orders-end.png |
| 19 | CURSOR-BUY-CART-POSITION-ALL-SURFACES-20260922 | partial_child_open: Cart fixed on main Shop/Wholesale/Orders/Offers and Wholesale Store; nested Recent route loses aggregate Cart access (R6633-D02). | redmi/003-r6633-startup.png, redmi/005-product-scrolled.png, redmi/017-wholesale.png, redmi/026-orders.png, redmi/030-offers.png, redmi/032-wholesale-store.png, redmi/043-product-actions.png |
| 20 | CURSOR-BUY-PRODUCT-INFORMATION-REDESIGN-20260922 | observed_frontend_pass: Grouped product/price, Store, delivery/returns and action sections shared across root Shop, Wholesale and nested Recent product. | redmi/005-product-scrolled.png, redmi/031-wholesale-product.png, redmi/043-product-actions.png |
| 21 | CURSOR-BUY-CATEGORY-SEARCH-CONSISTENCY-20260922 | observed_frontend_pass_partial_matrix: Thin Store category header, thumbnails, full-height drag, Store filter safe area and Store-scoped price/search verified. Wholesale tiles/search match. Full route/large-text matrix covered locally, not exhaustively rerun on device. | redmi/011-store-categories.png, redmi/012-category-expanded.png, redmi/015-store-filter.png, redmi/016-store-price-filter.png, redmi/032-wholesale-store.png, redmi/034-wholesale-store-search-stable.png |
| 22 | CURSOR-BUY-SHOPPING-AREA-CURRENT-LOCATION-20260922 | observed_frontend_pass_google_deferred: Compact current-location popup reports unavailable without changing area; close and retry visible above Android navigation. Real Google location/map provider explicitly deferred. | redmi/037-current-location-popup.png |

## Preservation and limitations

No checkout/order/payment/message submitted; no reinstall/data clear. Six packs and one Saved item retained. Work address and Delivery restored; device left on Shop. INR300 total difference remains investigation O01. Google location/map, authentic Store/provider/photos, live authentication, fleet/slots and payments remain deferred. RB022 recipient edit and specific Offers order/invoice context require next targeted device replay; not falsely marked passed. Two confirmed child defects and one investigation registered; no new runtime edits after frozen source.

Failed diagnostic/focused test runs and tool attempts are retained with final passing evidence. Initial installer parsing failed before install because Android bat output was echoed; process-local DEBUG removal fixed parsing without changing the APK. Hierarchy unavailable during some animations is marked in each screenshot receipt.
