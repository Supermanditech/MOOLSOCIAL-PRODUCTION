# Founder correction — platform-assigned MoolSocial delivery

23 September 2026, Annotation1. Current requirements for R6633-D08, D09, D10 and related D06-G acceptance. Registration only. This correction supersedes the earlier proposed Express / Choose a delivery time / Standard wording and ALL buyer-selected delivery-service or time-slot requirements in the earlier audit, its preview matrix and related handoff. Earlier evidence remains historical; it must not be used to implement those rejected choices. No new ticket count and no app/backend implementation.

## Founder operating rule

The customer does not select delivery service or a delivery time. Supplier/Store and MoolSocial logistics partners operate through MoolSocial's delivery algorithm. The platform determines the eligible delivery service, schedule and current estimate using authoritative supplier and logistics inputs. Small eligible orders use quick biker delivery. Wholesale and bulk delivery are scheduled. Remote courier delivery is also scheduled. A buyer being retail, Wholesale or bulk does not create an independent delivery chooser.

Proposed professional platform service labels, recorded for implementation review:

| Scenario | Customer-facing service label | Timing |
| --- | --- | --- |
| Eligible small order, biker/rider | MoolSocial Quick Delivery | Current platform estimate based on Store readiness and logistics availability |
| Wholesale or bulk delivery | MoolSocial Scheduled Delivery | Platform-assigned delivery date/window from supplier and logistics planning |
| Remote courier delivery | MoolSocial Courier Delivery | Also scheduled; show the platform-provided delivery date/window and carrier updates |

Courier is the delivery service; scheduled describes its timing. Keep these as separate data dimensions so courier orders do not lose their schedule. Wholesale/bulk classification, pack size, MOQ, vehicle capacity and delivery schedule are distinct. Do not invent the small-order threshold, vehicle capacity, distance cutoff, service duration or algorithm. Those come from the agreed platform/provider contract. Multiple internal feasible services are inputs to platform assignment, not consumer radio buttons. If reassignment changes the delivery promise, show the authoritative update clearly; do not silently keep the old estimate.

## Product → checkout → order presentation

Product description: show the delivery type and timing supplied from the Store/supplier and platform data already intended for this page. A concise service label plus one timing line suffices. If an estimate is provisional or unavailable, label that accurately. Do not wait until after purchase to reveal material delivery timing or charges.

Cart and checkout: show the platform-assigned delivery service/estimate or schedule and relevant charge per authoritative delivery group as read-only information. No service picker, slot picker, Express upgrade or customer-booked time. Revalidate Store/stock/location/capacity/quote before order placement; show unavailable or changed information with the existing recovery flow. Address changes are customer inputs, but the delivery algorithm recomputes the assignment. Preserve existing payment review and explicit approval of material order changes, not an invented delivery choice.

After placement: show the assigned service and current order/delivery state, supplied schedule/ETA and updates from the same Store/order/logistics job. Quick orders can show live rider progress when supported. Scheduled Wholesale/bulk orders show their delivery window and preparation/dispatch progress, then live progress where supported. Courier orders show their scheduled arrival and carrier milestones; do not fabricate GPS tracking or a rider. Use customer status phrases such as Preparing your order, Scheduled for [provider date/window], On the way, Delayed and Delivered only when supported by the actual event. Service names and status messages are different fields; a scheduled service can later be On the way without changing its service identity.

The earlier separately approved Collect at store path is not redesigned by this wording correction. This correction removes customer choice among delivery services/time slots; it does not silently cancel the existing collection ticket or invent new pickup rules.

## Corrected ticket acceptance

- D08: platform service wording, source-backed assignment and scheduling. Replace buyer-selected slot with provider-assigned schedule. D08-C1 now requires carrying assigned schedule independently of transport, including scheduled courier and bulk delivery, without falling back to courier when eligibility is missing. Preserve existing freshness/location/Store/fleet checks; do not assume the old requirement for a consumer-booked slot defines the future provider contract. Coordinate the exact schedule/assignment semantics before changing shared fields.
- D09: platform-assigned delivery grouping, verified timing/charges and compact review. Absence of a delivery-service chooser is NOT a defect under this corrected rule. Stable Store/fulfilment/quote identity risk D09-C1 remains open. Do not merge or split physical deliveries merely to simplify the UI. Recompute assignment after quantity/address changes and handle unavailable service without inviting an unsupported alternative selection.
- D10: consistent live/scheduled/courier updates for consumers, Wholesale customers, retailers buying stock and bulk buyers. Backend/provider assignment and status events remain prerequisites. No delivery success, exact ETA, schedule reservation or moving map is fabricated in frontend fixtures.
- D06-G: compact premium Cart through checkout/tracking remains required. Replace the earlier slot-picker and service-choice preview requirements with read-only assigned-service/schedule views, plus updated/delayed/unavailable states. Keep one main action and compact aligned service/time/charge rows.

Future checks: small-order eligibility and capacity boundary from provider fixtures, Wholesale/bulk scheduled windows, remote courier schedule, changed location/quantity/stock, Store closed, unavailable partner, expired/missing assignment, revised timing/fees, reassigned logistics job, multi-Store split orders, out-of-order events, offline/reconnect, all buyer roles and accessible compact layouts. Ensure no delivery-service or time-slot selector appears. Live acceptance waits for actual supplier/logistics integration; this document does not implement the delivery algorithm or provider workspaces.

No Redmi interaction, app/test/config/policy edits, data injection, APK or transactions in this correction. Existing screenshots and source audit remain preserved. D07 auth correction and all prior open defects remain unchanged in status. This is the operative requirement for the later implementation batch.
