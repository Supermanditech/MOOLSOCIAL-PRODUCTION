# Cursor Buy: next Redmi APK inclusion reconciliation

Installed baseline: r66.32, verified by version and on-device SHA-256.

**22 frontend tickets = 11 + 3 + 8.** Related child fixes are included under their parent tickets, not counted again. Frontend completion does not imply live provider completion.

| # | Ticket | Scope | First source commit |
| --- | --- | --- | --- |
| 1 | RB006 | Store names in Cart and checkout | a78b1b38 |
| 2 | RB007 | Expanded Store-scoped search | a78b1b38 |
| 3 | RB008 | Store naming through draft and Maps handoff | a78b1b38 |
| 4 | RB011 | Pickup checkout retained through sign-in Back | a78b1b38 |
| 5 | RB012 | Unavailable-provider/payment recovery frontend | a78b1b38 |
| 6 | RB013 | Remove pickup banners; compact Recent Add; area tick contrast | a78b1b38 |
| 7 | RB018 | Compact payment-benefit cards | a78b1b38 |
| 8 | RB022 | Recipient-field accessibility and focus | a78b1b38 |
| 9 | RB026 | Correct active-delivery estimate wording | a78b1b38 |
| 10 | RB029 | Exact Store/SKU/variant identities and missing-data handling | a78b1b38 |
| 11 | ELIGIBILITY-11 | Explicit Quick/Scheduled/Wholesale/Bulk frontend eligibility contracts | a78b1b38 |
| 12 | CURSOR-BUY-QUANTITY-WIDTH-20260922 | Compact product quantity control | d9ec753b |
| 13 | CURSOR-BUY-DELIVERY-PROVENANCE-20260922 | Delivery rail requires current active-order provenance | d9ec753b |
| 14 | CURSOR-BUY-CART-SCROLL-STABILITY-20260922 | Stable Cart while scrolling product details | d9ec753b |
| 15 | CURSOR-BUY-COMPARE-SHEET-REGRESSION-20260922 | Compact Compare sheet | f4d2e116 |
| 16 | CURSOR-BUY-SEARCH-DELIVERY-FLEET-20260922 | Hide Delivery throughout search | f4d2e116 |
| 17 | CURSOR-BUY-ORDER-INVOICE-ACTIONS-20260922 | Compact order and invoice actions | f4d2e116 |
| 18 | CURSOR-BUY-MVP-MEDICINE-PROMO-20260922 | Remove deferred Medicine promotion | f4d2e116 |
| 19 | CURSOR-BUY-CART-POSITION-ALL-SURFACES-20260922 | Fixed Cart across public Buy surfaces | f4d2e116 |
| 20 | CURSOR-BUY-PRODUCT-INFORMATION-REDESIGN-20260922 | Organized product information across public entry points | f4d2e116 |
| 21 | CURSOR-BUY-CATEGORY-SEARCH-CONSISTENCY-20260922 | Shared scoped categories, expanding search and thumbnails | f4d2e116 |
| 22 | CURSOR-BUY-SHOPPING-AREA-CURRENT-LOCATION-20260922 | Compact current-location popup frontend | f4d2e116 |

Source reconciliation: 3,233 inputs present and tracked; zero Git-blob mismatches or ignored lib/assets; 16 post-APK work commits, four runtime commits; all 18 required integrated tips retained. Nine substantive Buy runtime-file changes, one generated-Java line-ending-only difference and eight test-file changes compared with the actual APK source manifest. Store/native/backend Git trees remain unchanged.

Git is safe for candidate preparation. This is not a built or qualified new APK. Google/live-provider dependencies remain deferred. The four-file legacy test patch is archived and verified externally, but not applied. Full new-candidate qualification and Redmi replay remain outstanding.
