# Redmi Add → Cart → checkout → order replay, 23 September 2026

Registration-only replay. Six NEW OPEN findings R6633-D11–D16 and new evidence linked to existing D07, D09, D10, D06-G and D06-G-C1. No application implementation, source/test/configuration/policy change or APK. Founder specifically reported payment selection not advancing and authorized expanded real-user taps through each end intent.

Checkpoint965d5e4f84065ac97c9e0e6b486fa6e7d0da4b89, Cursor Buy worktree and branch unchanged. Installed Redmi TG8HCYTGGQT885OF: com.moolsocial.app.cursorreview, r66.33-cursorreview code2026092202, SHA256968933D16519BBE6AC757C10ACA39368F87A7605CFAB0CF1F6C4E28DD73E1FC7. All results below are actual device taps against this existing review build, with read-only source tracing for causes. No separately invented or injected catalogue, order or payment provider was added.

## Direct answer to the payment report

The screen can stall for DIFFERENT reasons. At founder-current103, Wholesale Paytm is already paymentActionRequired but the app has no payment handoff, so the primary button says Unavailable. Choosing another method does not reset it. Cancel changes the state but still requires a second Choose again action before methods work. In fresh ordinary delivery checkout, selecting an eligible method DOES reach final review:108,123,141,163. Place order then returns online methods to the unavailable payment screen:109,124,142,164. In collection checkout, selected PhonePe/Paytm/Pine Labs never enable Review order because collection identity/controller/gateway prerequisites are missing:118–121. Purchase order with an empty reference is correctly rejected, but its required field is below the viewport and the UI fails to reveal it:151/152. Bulk and some Store products reach review but cannot confirm delivery:154/155/170. These outcomes must not be collapsed into one generic button fix or solved by weakening validation.

## State preservation and safe endpoints

Start: founder had one Wholesale SKU (Fresh red onions,25kg sacks), two packs, ₹1550, Paytm selected, an unavailable attempt. Shop had zero items. Existing orders and Saved lists remained. Test additions: Shop tomato1, Wholesale bananas2, Bulk rice4, Offers Shop tomato1, Visit Store atta1. The first Shop tomato was placed through the EXISTING review-only Cash on Delivery adapter, producing local purchase BUY-NEW-05 / order MS-NEW-10, ₹37. It is a simulated local order, NOT a supplier order, actual COD request, paid order or live delivery. The adapter was read first: _BuyV2DeviceReviewCommerceAdapter in buy_v2_session.dart handles these calls locally; its online methods return paymentActionRequired and no handoff is injected. No external payment URL was opened, no real payment/message made and no provider workflow was invoked.

The local review order is retained as test evidence, not deleted or counted as backend acceptance. Its original order count/route state was not otherwise changed. All other test-added products were removed explicitly via their own quantity controls; the original two onion packs/₹1550 remained intact (176/183). Temporary reference AUDIT-R6633-LOCAL was entered to test the form, then cleared back to its original empty value (181/182). The below-minimum PhonePe benefit selection was removed; no offer remains selected. Final183: original Wholesale basket, Paytm selected, payment state recovered/idle with Review order available. The original failed attempt was cancelled during the recovery test and was not artificially recreated at the end. No address or Saved edits. Catalogue filters/navigation/scroll changed during browsing, not reset through app-data deletion.

Invoice download opened Android's save picker; the picker was cancelled, and the app displayed Invoice save cancelled. No PDF-save success is claimed. Raw132 and133 contain unrelated Android picker/account/directory information and remain local-only; they are excluded from the Git archive. Other evidence remains unmodified.131 is the picker splash;134 proves cancellation returned to the invoice.125's filename suggests COD review, but the actual image still shows unavailable Paytm because the attempted Cancel tap missed after layout movement; only127 is valid COD review evidence. Screenshot labels are not treated as proof against their contents.

## Findings

### R6633-D11 — Online payment methods reach a dead end after final review

P1 functional integration blocker; mvp_required. Actual paths: Wholesale PhonePe108→109; Shop Paytm123→124; fresh Wholesale Pine Labs141→142; Offers-origin Shop Pine Labs163→164. Founder-current Paytm103 is the same failure class. Method selection can succeed and Review order can advance, but Place order returns to Payment with Unavailable and no usable provider action.

Source evidence: _checkoutPrimaryAction in buy_v2_views.dart (~7524) returns a disabled Unavailable action when state is paymentActionRequired and paymentHandoff is null. _BuyV2DeviceReviewCommerceAdapter.placeOrder (~285) returns that state for PhonePe/Paytm/Pine Labs. Searching apps/mobile/lib finds only handoff forwarding, no runtime paymentHandoff provider. This is missing integration, not evidence that internet failed, payment was declined or money was debited.

Expected: method readiness is accurate before the customer commits to an unavailable path; reuse the existing handoff/placement/reconciliation interfaces, exact payment intent and authoritative provider result. Missing configuration must have an honest unavailable/recovery state. Do not fabricate paid success or auto-confirm from a return URL. Test idle→review→provider handoff→pending/failed/cancelled/unknown/confirmed with proper idempotency and basket retention. Actual payment/provider completion remains a backend/provider dependency; fixture success is not live qualification. No new payment SDK or backend is introduced by registration.

### R6633-D12 — Payment recovery looks selectable while locked; cancellation still says complete payment

P1 usability/state defect linked D11.103→104: tap PhonePe during unavailable Paytm; selection stays Paytm and notice says Complete the current payment before changing the method.105→106: after Cancel, the screen explicitly says cancelled/no order, yet tapping PhonePe produces the SAME instruction. Only Choose again restores idle/review in107.112: the unresolved unavailable Wholesale attempt blocks adding a Shop tomato;113 confirms no Shop item was added.114 returns to the unavailable payment. After explicit cancel/reset,115 adds the product correctly.

Source: _CheckoutPaymentStage treats only idle as selecting; all other states render apparently active choices whose onTap only shows the complete-payment notice. cancelPaymentAttempt sets cancelled; a separate retry action must restore idle. checkoutRequiresResolution includes paymentActionRequired and drives shared Cart mutation protection. The protection for genuine pending/unknown payments must remain. Do not blanket-unlock all baskets on a network error or clear uncertain payment IDs just to permit another purchase.

Expected: distinguish never-launched/unavailable handoff from provider-pending/unknown, show the actual recovery action and make the state of method controls clear. After confirmed local cancellation, enable a coherent choose-another-method flow without a contradictory complete-payment message. D12-C1: a failed/not-launched attempt currently obstructs independent Shop Add; assess exact payment-intent/basket scope, with safe cancellation/reconciliation and a visible route back to that intent. Test cross-Shop/Wholesale/Offers navigation, terminal cancellation, reentry and app restore while preserving genuine duplicate-payment protection.

### R6633-D13 — Wholesale dispatch promise is presented as arrival

P1 delivery-promise correctness, mvp_required.108/141/154/160: review row says Arrives · Dispatch within one day. This is not a delivery arrival window. UI _CheckoutDeliverySummaryCard uses group.hasDeliveryEstimate to choose Arrives and renders the shared promise summary; the current review records carry a dispatch phrase into this path.

Expected: separate dispatch readiness, platform-assigned delivery schedule and arrival estimate. Show Dispatches within… for a dispatch fact, and show arrival as unavailable/not yet confirmed unless supported by the authoritative quote. Preserve the platform-assigned rule from the founder correction: no customer delivery/slot chooser. Do not derive exact delivery timing by rewording a dispatch string. Test dispatch-only, scheduled courier, Wholesale/bulk, changed promise and stale quote. Reuse existing promise/quote and compact summary owners; coordinate missing provider fields. Final order placement must follow the correct authoritative promise/quote checks.

### R6633-D14 — New Cart and Edit basket reopen at recommendations, hiding the items to edit

P2 navigation/visual defect, child of D06-G.116 after fresh Shop Add,158 after Offers Add and168 after Visit Store Add reopen Cart deep in discovery content rather than showing newly added products.160→161: Edit basket from blocked final review returns to a recommendations region, not the actual basket lines. Reaching the actual lines required multiple upward scrolls,171. Quantities/totals stayed correct; this is not lost basket data.

Source candidate: BuyV2CartView uses a retained _scrollController and PageStorageKey per cart scope (~6076/6100). Exact offset/root interaction is not yet instrumented, so do not claim a proved framework defect. Expected: reveal added/affected basket lines when entering from Add or Edit basket; sensible independent scope offsets; preserve useful scroll for ordinary back navigation instead of blindly resetting every visit. Show Cart items before secondary recommendations. Test new product, same product, different scope, return from blocked review, long mixed basket, remove item and narrow/large-text layout. Existing D06 oversized headers/browsing buttons/discovery cards remain visible and open, not implemented by this replay.

### R6633-D15 — Required purchase-order reference is offscreen and validation does not reveal it

P2 validation/accessibility, mvp_required.150→151: select Purchase order and Review order with empty reference. A notice asks for the reference, but the view remains with method cards and no visible field. Scrolling manually reveals it in152; its helper text is truncated.153: entered the explicitly local test reference with keyboard;154 then reached review and correctly stopped for unavailable delivery. Clearing it was verified in182.

Source: continueCheckoutFromPayment (~8930) sets a notice for missing purchaseOrderDetailsComplete but does not request focus/scroll; TextFormField is appended after the method list in _CheckoutPaymentStage (~8337). Expected: required field is readily visible on choosing that method, concise inline error and focus/scroll when Review is attempted, full accessible helper text, keyboard-safe action and Android insets. Preserve the validation; do not allow blank/invalid procurement reference or imply a local test reference is approved business credit. Test blank, valid, long, focus/dismiss/back and changing to a method that does not need this field. Link D06-G-C1:159 re-reproduces the orphan test reference in mixed Shop/Wholesale payment where Purchase order is not a valid choice; method selection was correctly gated but the stale field remained visible.

### R6633-D16 — Customer Store/product display names change after ordering

P2 presentation/identity consistency. Product165/review123 show Mool Market1 and Fresh tomatoes. Local confirmation128 and tracking136 show Mool Market000001; invoice129/130 shows Fresh tomatoes1. Source: post-order views use order.partner directly (~19799/19919); invoice uses order.partner and persisted order lines. This is reproducible review-data presentation leakage; it does not prove real Store records are corrupt.

Expected: public display names are mapped consistently at the order snapshot boundary and reused across confirmation/tracking/invoice. Preserve stable Store/SKU/variant IDs, quantities and price; never strip numeric characters indiscriminately from legitimate product names or rewrite legal invoice seller identity. If legal entity differs from public Store name, label the distinction explicitly. Test digit-bearing genuine names, generated review identity, long names, multiple same-name Stores and product variants. Coordinate exact authoritative Store/public mapping; no edits to Codex's worktree.

## Existing issues strengthened, not duplicated or closed

- D07: collection identity/gateway absent; fresh Add-to-collection118–121 leaves Review order disabled for PhonePe, Paytm and Pine Labs. Expected fix remains authenticated app identity plus service wiring, not hiding validation or inventing a user ID.
- D09: Bulk rice154/155 and Store atta170 cannot obtain delivery timing; Check delivery retry returns unavailable. Blocking placement is correct; the unresolved delivery/provider outcome remains open. Existing dispatch/arrival flaw is isolated as D13.
- D10: newly created LOCAL test order136 still has last-known preparing state, no partner and no live updates. No real delivery lifecycle closed.
- D06-G-C1: mixed Offers payment159 has an orphan PO reference after the PO method becomes ineligible. Existing defect reproduced with a controlled temporary value, then cleared.
- D06-G: wide Cart controls, repeated Wholesale line/detail sections, oversized delivery instructions and payment panels remain; full compact premium polish is still required. D04 white Store Cart band remains visible166; the screenshot shows the Cart action itself is visible, so XML's clipped bounds alone are not recorded as a new Android-hidden defect.

## Journey / end-intent matrix

| Check | Actual endpoint and evidence | Result |
| --- | --- | --- |
| Founder-current unavailable Paytm → change method |103–104 selection locked | D11/D12 reproduced |
| Cancel → another method → Choose again |105–107 contradictory cancelled-state notice then recovery | D12 reproduced; explicit reset works |
| Wholesale PhonePe → review → Place order |108–109 returns unavailable | D11, not charged |
| Shop Add while unavailable Wholesale payment |110–114 no item added; reopens payment | D12-C1 |
| Fresh Shop Add after recovery |115–116 one item₹37, correct separate Wholesale balance | Add/count pass; D14 offset |
| Shop collection PhonePe |118 selected, disabled review | D07 dependency |
| Shop collection Paytm |119 selected, disabled review | D07 dependency |
| Shop collection Pine Labs |120 selected, disabled review | D07 dependency |
| Shop delivery Paytm → review → Place order |122–124 unavailable handoff | D11 |
| Shop COD → review → local confirmation |127–128 BUY-NEW-05 / MS-NEW-10 | Local fixture endpoint only; D16 names |
| New order invoice → Download → Cancel |129–134 Android save picker then Invoice save cancelled | Navigation/cancel pass; actual saved PDF not tested |
| New order → tracking |135–136 preparing/last-known, no live provider | D10 dependency |
| Wholesale fresh Add MOQ |137–139 bananas added as2 packs; original onions retained | Quantity/count pass |
| Shop COD carried into Wholesale payment |140 no eligible method selected, Choose payment method disabled | Correct protection |
| Fresh Wholesale Pine Labs → review → Place order |141–142 unavailable | D11; D13 promise |
| Bulk category with no matching products → Best prices |143–145 empty category recovers to actual Bulk rice | Filter recovery pass, not missing catalogue |
| Bulk Add4 → quantity1 → Update → Cancel |146–149 inline minimum4, Cart keeps4 | MOQ/keyboard/cancel pass |
| Bulk PO with empty reference → Review |150–152 notice, field offscreen | Validation blocks correctly; D15 UX |
| PO reference entry with keyboard → review |153–154 reaches blocked delivery review | Reference validation pass; provider blocked |
| Bulk Check delivery retry |155 still unavailable | D09 dependency |
| Expired Offers → Refresh |156–157 current list returns | Freshness recovery pass |
| Offers retail Add → mixed basket → payment |158–159 correct total₹9987; orphan PO reference | D06-G-C1; D14 offset |
| Offers mixed payment → review → Edit basket |160–161 delivery blocked then wrong Cart viewport | D09/D14 |
| Offers Shop-only scope → Pine Labs → review → Place order |162–164 correct₹37 then unavailable | D11 |
| Shop product → Visit Store → Add atta → Cart |165–168 Store-scoped product Add, Shop total₹316 | Identity/count pass; D14 offset |
| Visit Store-added basket → payment → review |169–170 unconfirmed atta delivery | D09 dependency |
| Remove only test bananas/rice/tomato/atta |171–176 original onion basket₹1550 restored | Correct quantity/total removal |
| Cart Wholesale coupons |177 no eligible trade coupons | Honest empty state |
| Below-minimum payment offer selection |178–179 explicitly ineligible, saving not in total; then removed | Financial display protection pass |
| Restore reference/method/basket |180–183 original empty reference, Paytm,2packs₹1550, no benefit | Preserved; initial unavailable attempt recovered |

This is30 distinct route/state checks, not every mathematical combination of product, account, payment method and delivery state. Shop/Wholesale/Bulk/Offers/Visit Store share existing owners, but unexecuted combinations are not claimed as tapped. Offers Wholesale SKU purchase was not repeated separately from the freshly tested Wholesale catalogue path; its known bottom Add layout remains D06-E. Account-switched retailer procurement, real auth expiry, online payment success, genuine supplier acceptance, live driver/courier/bulk completion and production invoice download require their exact providers/accounts. No unavailable branch is marked passed. Earlier unchanged address-form checks079/080 remain prior evidence, not fresh replays. End intents beyond a blocking dependency remain pending under that dependency rather than retried indefinitely.

## Bounded future implementation ownership and acceptance

Reuse existing BuyV2Session and BuyV2CartView/checkout/payment/confirmation/tracking/invoice owners: apps/mobile/lib/features/buy/buy_v2_session.dart; apps/mobile/lib/ui_v2/buy/buy_v2_views.dart; buy_v2_invoice.dart; existing design/contract and payment handoff adapters only as required by coordinated ownership. Focused tests already exist for checkout Cart return, scoped Cart dock continuity, Wholesale payment attribution, payment sheet motion, invoice context/download/insets and live delivery. Extend only checks proving these concrete failures after implementation is authorized. No test suite rerun for this evidence-only change; exact3236-file source seal must remain unchanged.

Preserve latest platform-assigned delivery requirements: no new customer service/time selector; supplier/Store plus MoolSocial logistics algorithm owns assignment and timing. No policy/governance changes, new backend, package, release, payment bypass, another-worktree edits or fixes in this task. All six new findings and linked existing issues remain OPEN; this registration closes only the requested inspection/reporting work through available endpoints.
