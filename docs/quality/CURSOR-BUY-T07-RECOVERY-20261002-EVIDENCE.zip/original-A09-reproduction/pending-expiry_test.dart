import 'package:flutter_test/flutter_test.dart';
import 'package:moolsocial/features/buy/buy_session.dart';
import 'package:moolsocial/features/buy/buy_v2_cart_contracts.dart';
import 'package:moolsocial/features/buy/buy_v2_content_contracts.dart';
import 'package:moolsocial/features/buy/buy_v2_models.dart';
import 'package:moolsocial/features/buy/buy_v2_session.dart';
import '../../test/ui_v2/buy/buy_v2_session_test.dart' show prepaidCommerceFixture;

class _Commerce implements BuyV2CommerceAdapter {
  final delegate = prepaidCommerceFixture();
  BuyV2OrderPlacementRequest? request;
  @override
  Future<BuyV2CommerceSnapshot> refresh() => delegate.refresh();
  @override
  Future<BuyV2OrderPlacementResult> placeOrder(BuyV2OrderPlacementRequest value) {
    request = value;
    return delegate.placeOrder(value);
  }
  @override
  dynamic noSuchMethod(Invocation invocation) => throw StateError('unused');
}

class _Facts implements BuyV2ProductFactsAdapter {
  @override
  BuyV2ProductFactsSnapshot snapshotFor(BuyV2Product product) =>
      const BuyV2CatalogueProductFactsAdapter().snapshotFor(product).copyWith(
        deliveryPromise: 'within 5 min',
        promisedByLabel: 'by 6:35 PM',
        sourceId: 'b01-t01c-delivery-quote',
      );
}

class _Campaign extends BuyV2SeededCartBenefitsAdapter {
  _Campaign(this.until);
  final DateTime until;
  @override
  List<BuyV2CartBenefit> benefitsFor({
    required BuyV2CartBenefitKind kind,
    required Set<BuyV2Destination> destinations,
    required int itemTotal,
  }) => kind == BuyV2CartBenefitKind.coupon
      ? [BuyV2CartBenefit(
          id: 'pending-expiry', kind: kind, destination: BuyV2Destination.shop,
          title: 'Isolated timed coupon', detail: 'Review-only amount recovery reproduction',
          sourceId: 't04-expiry-test', savingAmount: 5, validUntil: until,
        )]
      : [];
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  test('T04 review-only pending expiry preserves submitted amount', () async {
    var now = DateTime.now();
    final core = BuySession();
    final commerce = _Commerce();
    final session = BuyV2Session(
      core: core, commerceAdapter: commerce, productFactsAdapter: _Facts(),
      cartBenefitsAdapter: _Campaign(now.add(const Duration(minutes: 1))),
      catalogueNow: () => now,
    );
    addTearDown(session.dispose);
    addTearDown(core.dispose);
    session.addProduct('s-tomato');
    expect(session.chooseCartBenefit(session.cartBenefits(kind: BuyV2CartBenefitKind.coupon).single), isTrue);
    session.openCart();
    expect(session.openCheckout(), isTrue);
    expect(session.continueCheckoutFromAddress(), isTrue);
    expect(session.choosePayment('Card'), isTrue);
    expect(session.continueCheckoutFromPayment(), isTrue);
    expect(await session.submitOrder(), isFalse);
    expect(session.checkoutRequiresResolution, isTrue);
    expect(commerce.request!.total, 32);
    now = now.add(const Duration(minutes: 2));
    expect(commerce.request!.total, 32);
    expect(session.checkoutAmountDueNow, 32);
  });
}
